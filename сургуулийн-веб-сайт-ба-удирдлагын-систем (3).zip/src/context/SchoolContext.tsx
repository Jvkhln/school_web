import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  CategoryItem,
  HeroSlide,
  SchoolProgram,
  NewsArticle,
  SchoolInfo,
  AdmissionInquiry,
  SectionTexts,
  CalendarEvent
} from '../types';
import {
  INITIAL_CATEGORIES,
  INITIAL_HERO_SLIDES,
  INITIAL_PROGRAMS,
  INITIAL_NEWS,
  INITIAL_SCHOOL_INFO,
  INITIAL_INQUIRIES,
  INITIAL_SECTION_TEXTS,
  INITIAL_CALENDAR_EVENTS
} from '../data/initialData';
import { db } from '../lib/firebase';
import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  onSnapshot,
  getDocs
} from 'firebase/firestore';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo = {
    error: error instanceof Error ? error.message : String(error),
    operationType,
    path
  };
  console.warn('Firestore Note: ', JSON.stringify(errInfo));
}

interface SchoolContextType {
  // State
  categories: CategoryItem[];
  heroSlides: HeroSlide[];
  programs: SchoolProgram[];
  news: NewsArticle[];
  schoolInfo: SchoolInfo;
  sectionTexts: SectionTexts;
  inquiries: AdmissionInquiry[];
  calendarEvents: CalendarEvent[];
  activeCategory: string | 'all';
  selectedProgramModal: SchoolProgram | null;
  selectedNewsModal: NewsArticle | null;
  isAdmissionModalOpen: boolean;
  isAdminOpen: boolean;
  isAdminLoginModalOpen: boolean;
  isAdminAuthenticated: boolean;
  adminUsername: string;
  searchQuery: string;
  isFirebaseConnected: boolean;

  // Setters & Triggers
  setActiveCategory: (categorySlug: string | 'all') => void;
  setSelectedProgramModal: (program: SchoolProgram | null) => void;
  setSelectedNewsModal: (article: NewsArticle | null) => void;
  setIsAdmissionModalOpen: (open: boolean) => void;
  setIsAdminOpen: (open: boolean) => void;
  setIsAdminLoginModalOpen: (open: boolean) => void;
  openAdmin: () => void;
  setSearchQuery: (query: string) => void;

  // Authentication
  loginAdmin: (username: string, pass: string) => { success: boolean; message?: string };
  logoutAdmin: () => void;
  updateAdminCredentials: (oldPass: string, newPass: string, newUsername?: string) => { success: boolean; message: string };

  // News CRUD
  addNewsArticle: (article: Omit<NewsArticle, 'id' | 'createdAt' | 'views'>) => void;
  updateNewsArticle: (id: string, updated: Partial<NewsArticle>) => void;
  deleteNewsArticle: (id: string) => void;

  // Programs CRUD
  addProgram: (program: Omit<SchoolProgram, 'id' | 'createdAt'>) => void;
  updateProgram: (id: string, updated: Partial<SchoolProgram>) => void;
  deleteProgram: (id: string) => void;

  // Hero Slides CRUD
  addHeroSlide: (slide: Omit<HeroSlide, 'id'>) => void;
  updateHeroSlide: (id: string, updated: Partial<HeroSlide>) => void;
  deleteHeroSlide: (id: string) => void;

  // Categories CRUD
  addCategory: (category: Omit<CategoryItem, 'id'>) => void;
  updateCategory: (id: string, updated: Partial<CategoryItem>) => void;
  deleteCategory: (id: string) => void;

  // School Info & Section Texts
  updateSchoolInfo: (info: Partial<SchoolInfo>) => void;
  updateSectionTexts: (texts: Partial<SectionTexts>) => void;

  // Admission & Inquiries
  submitAdmissionInquiry: (inquiry: Omit<AdmissionInquiry, 'id' | 'createdAt' | 'status'>) => void;
  updateInquiryStatus: (id: string, status: AdmissionInquiry['status']) => void;
  deleteInquiry: (id: string) => void;

  // Academic Calendar Plan CRUD
  addCalendarEvent: (event: Omit<CalendarEvent, 'id'>) => void;
  updateCalendarEvent: (id: string, updated: Partial<CalendarEvent>) => void;
  deleteCalendarEvent: (id: string) => void;

  // Backup & Reset
  resetToDefaults: () => void;
  exportDataJson: () => string;
  importDataJson: (jsonString: string) => boolean;
}

const SchoolContext = createContext<SchoolContextType | undefined>(undefined);

const STORAGE_KEYS = {
  CATEGORIES: 'school_categories_v1',
  SLIDES: 'school_slides_v1',
  PROGRAMS: 'school_programs_v1',
  NEWS: 'school_news_v1',
  INFO: 'school_info_v1',
  SECTION_TEXTS: 'school_section_texts_v1',
  INQUIRIES: 'school_inquiries_v1',
  CALENDAR: 'school_calendar_events_v1',
  ADMIN_AUTH: 'school_admin_auth_v1',
  ADMIN_USER: 'school_admin_username_v1',
  ADMIN_PASS: 'school_admin_password_v1'
};

export const SchoolProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load initial states from localStorage with default fallbacks
  const [categories, setCategories] = useState<CategoryItem[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
    return saved ? JSON.parse(saved) : INITIAL_CATEGORIES;
  });

  const [heroSlides, setHeroSlides] = useState<HeroSlide[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SLIDES);
    return saved ? JSON.parse(saved) : INITIAL_HERO_SLIDES;
  });

  const [programs, setPrograms] = useState<SchoolProgram[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PROGRAMS);
    return saved ? JSON.parse(saved) : INITIAL_PROGRAMS;
  });

  const [news, setNews] = useState<NewsArticle[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.NEWS);
    return saved ? JSON.parse(saved) : INITIAL_NEWS;
  });

  const [schoolInfo, setSchoolInfo] = useState<SchoolInfo>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.INFO);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.name && parsed.name.includes('Өргөө')) {
          parsed.name = 'Эрдмийн Далай Цогцолбор Сургууль';
        }
        return parsed;
      } catch (e) {
        // fallback
      }
    }
    return INITIAL_SCHOOL_INFO;
  });

  const [sectionTexts, setSectionTexts] = useState<SectionTexts>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SECTION_TEXTS);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.aboutTitle && parsed.aboutTitle.includes('Өргөө')) {
          parsed.aboutTitle = 'Эрдмийн Далай Цогцолбор Сургуульд тавтай морилно уу';
        }
        return parsed;
      } catch (e) {
        // fallback
      }
    }
    return INITIAL_SECTION_TEXTS;
  });

  const [inquiries, setInquiries] = useState<AdmissionInquiry[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.INQUIRIES);
    return saved ? JSON.parse(saved) : INITIAL_INQUIRIES;
  });

  const [calendarEvents, setCalendarEvents] = useState<CalendarEvent[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CALENDAR);
    return saved ? JSON.parse(saved) : INITIAL_CALENDAR_EVENTS;
  });

  const [isFirebaseConnected, setIsFirebaseConnected] = useState<boolean>(false);

  // Admin Authentication State
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ADMIN_AUTH);
    return saved === 'true';
  });

  const [adminUsername, setAdminUsername] = useState<string>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ADMIN_USER);
    return saved || 'admin';
  });

  const [adminPassword, setAdminPassword] = useState<string>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ADMIN_PASS);
    return saved || 'admin123';
  });

  // UI States
  const [activeCategory, setActiveCategory] = useState<string | 'all'>('all');
  const [selectedProgramModal, setSelectedProgramModal] = useState<SchoolProgram | null>(null);
  const [selectedNewsModal, setSelectedNewsModal] = useState<NewsArticle | null>(null);
  const [isAdmissionModalOpen, setIsAdmissionModalOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isAdminLoginModalOpen, setIsAdminLoginModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Firestore Real-Time Subscriptions & Initialization
  useEffect(() => {
    let unsubSchoolInfo: (() => void) | undefined;
    let unsubSectionTexts: (() => void) | undefined;
    let unsubPrograms: (() => void) | undefined;
    let unsubNews: (() => void) | undefined;
    let unsubCategories: (() => void) | undefined;
    let unsubSlides: (() => void) | undefined;
    let unsubCalendar: (() => void) | undefined;
    let unsubInquiries: (() => void) | undefined;

    try {
      // 1. School Info listener
      unsubSchoolInfo = onSnapshot(doc(db, 'settings', 'schoolInfo'), (snapshot) => {
        if (snapshot.exists()) {
          setSchoolInfo(snapshot.data() as SchoolInfo);
          setIsFirebaseConnected(true);
        }
      }, (err) => handleFirestoreError(err, OperationType.GET, 'settings/schoolInfo'));

      // 2. Section Texts listener
      unsubSectionTexts = onSnapshot(doc(db, 'settings', 'sectionTexts'), (snapshot) => {
        if (snapshot.exists()) {
          setSectionTexts(snapshot.data() as SectionTexts);
          setIsFirebaseConnected(true);
        }
      }, (err) => handleFirestoreError(err, OperationType.GET, 'settings/sectionTexts'));

      // 3. Programs listener
      unsubPrograms = onSnapshot(collection(db, 'programs'), (snapshot) => {
        if (!snapshot.empty) {
          const progs = snapshot.docs.map(d => ({ id: d.id, ...d.data() })) as SchoolProgram[];
          setPrograms(progs);
          setIsFirebaseConnected(true);
        }
      }, (err) => handleFirestoreError(err, OperationType.LIST, 'programs'));

      // 4. News listener
      unsubNews = onSnapshot(collection(db, 'news'), (snapshot) => {
        if (!snapshot.empty) {
          const items = snapshot.docs.map(d => ({ id: d.id, ...d.data() })) as NewsArticle[];
          setNews(items);
          setIsFirebaseConnected(true);
        }
      }, (err) => handleFirestoreError(err, OperationType.LIST, 'news'));

      // 5. Categories listener
      unsubCategories = onSnapshot(collection(db, 'categories'), (snapshot) => {
        if (!snapshot.empty) {
          const cats = snapshot.docs.map(d => ({ id: d.id, ...d.data() })) as CategoryItem[];
          setCategories(cats);
          setIsFirebaseConnected(true);
        }
      }, (err) => handleFirestoreError(err, OperationType.LIST, 'categories'));

      // 6. Slides listener
      unsubSlides = onSnapshot(collection(db, 'slides'), (snapshot) => {
        if (!snapshot.empty) {
          const s = snapshot.docs.map(d => ({ id: d.id, ...d.data() })) as HeroSlide[];
          setHeroSlides(s);
          setIsFirebaseConnected(true);
        }
      }, (err) => handleFirestoreError(err, OperationType.LIST, 'slides'));

      // 7. Calendar listener
      unsubCalendar = onSnapshot(collection(db, 'calendar'), (snapshot) => {
        if (!snapshot.empty) {
          const events = snapshot.docs.map(d => ({ id: d.id, ...d.data() })) as CalendarEvent[];
          setCalendarEvents(events);
          setIsFirebaseConnected(true);
        }
      }, (err) => handleFirestoreError(err, OperationType.LIST, 'calendar'));

      // 8. Inquiries listener
      unsubInquiries = onSnapshot(collection(db, 'inquiries'), (snapshot) => {
        if (!snapshot.empty) {
          const inqs = snapshot.docs.map(d => ({ id: d.id, ...d.data() })) as AdmissionInquiry[];
          setInquiries(inqs);
          setIsFirebaseConnected(true);
        }
      }, (err) => handleFirestoreError(err, OperationType.LIST, 'inquiries'));

    } catch (e) {
      console.warn('Firestore subscription initialized with offline fallback', e);
    }

    return () => {
      if (unsubSchoolInfo) unsubSchoolInfo();
      if (unsubSectionTexts) unsubSectionTexts();
      if (unsubPrograms) unsubPrograms();
      if (unsubNews) unsubNews();
      if (unsubCategories) unsubCategories();
      if (unsubSlides) unsubSlides();
      if (unsubCalendar) unsubCalendar();
      if (unsubInquiries) unsubInquiries();
    };
  }, []);

  // Persist to localStorage as instant cache
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(categories));
  }, [categories]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SLIDES, JSON.stringify(heroSlides));
  }, [heroSlides]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PROGRAMS, JSON.stringify(programs));
  }, [programs]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.NEWS, JSON.stringify(news));
  }, [news]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.INFO, JSON.stringify(schoolInfo));
  }, [schoolInfo]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SECTION_TEXTS, JSON.stringify(sectionTexts));
  }, [sectionTexts]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.INQUIRIES, JSON.stringify(inquiries));
  }, [inquiries]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CALENDAR, JSON.stringify(calendarEvents));
  }, [calendarEvents]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ADMIN_AUTH, String(isAdminAuthenticated));
  }, [isAdminAuthenticated]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ADMIN_USER, adminUsername);
  }, [adminUsername]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ADMIN_PASS, adminPassword);
  }, [adminPassword]);

  // Authentication Handlers
  const loginAdmin = (username: string, pass: string) => {
    const normalizedUser = username.trim().toLowerCase();
    const currentAdminUser = adminUsername.trim().toLowerCase();

    const isUserValid =
      normalizedUser === currentAdminUser ||
      normalizedUser === 'admin' ||
      normalizedUser === 'admin@school.edu.mn';

    if (isUserValid && pass === adminPassword) {
      setIsAdminAuthenticated(true);
      setIsAdminLoginModalOpen(false);
      setIsAdminOpen(true);
      return { success: true };
    } else {
      return { success: false, message: 'Нэвтрэх нэр эсвэл нууц үг буруу байна!' };
    }
  };

  const logoutAdmin = () => {
    setIsAdminAuthenticated(false);
    setIsAdminOpen(false);
    localStorage.removeItem(STORAGE_KEYS.ADMIN_AUTH);
  };

  const updateAdminCredentials = (oldPass: string, newPass: string, newUsername?: string) => {
    if (oldPass !== adminPassword) {
      return { success: false, message: 'Одоогийн нууц үг тохирохгүй байна!' };
    }
    if (!newPass || newPass.length < 4) {
      return { success: false, message: 'Шинэ нууц үг хамгийн багадаа 4 тэмдэгттэй байх ёстой!' };
    }
    setAdminPassword(newPass);
    if (newUsername && newUsername.trim()) {
      setAdminUsername(newUsername.trim());
    }
    return { success: true, message: 'Админы мэдээлэл амжилттай солигдлоо!' };
  };

  const openAdmin = () => {
    if (isAdminAuthenticated) {
      setIsAdminOpen(true);
    } else {
      setIsAdminLoginModalOpen(true);
    }
  };

  // News CRUD Actions
  const addNewsArticle = async (newArt: Omit<NewsArticle, 'id' | 'createdAt' | 'views'>) => {
    const newId = 'news-' + Date.now();
    const newItem: NewsArticle = {
      ...newArt,
      id: newId,
      views: 0,
      createdAt: new Date().toISOString()
    };
    setNews(prev => [newItem, ...prev]);
    try {
      await setDoc(doc(db, 'news', newId), newItem);
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, `news/${newId}`);
    }
  };

  const updateNewsArticle = async (id: string, updated: Partial<NewsArticle>) => {
    setNews(prev => prev.map(item => (item.id === id ? { ...item, ...updated } : item)));
    try {
      const existing = news.find(n => n.id === id);
      if (existing) {
        await setDoc(doc(db, 'news', id), { ...existing, ...updated }, { merge: true });
      }
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `news/${id}`);
    }
  };

  const deleteNewsArticle = async (id: string) => {
    setNews(prev => prev.filter(item => item.id !== id));
    try {
      await deleteDoc(doc(db, 'news', id));
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, `news/${id}`);
    }
  };

  // Programs CRUD Actions
  const addProgram = async (newProg: Omit<SchoolProgram, 'id' | 'createdAt'>) => {
    const newId = 'prog-' + Date.now();
    const newItem: SchoolProgram = {
      ...newProg,
      id: newId,
      createdAt: new Date().toISOString()
    };
    setPrograms(prev => [...prev, newItem]);
    try {
      await setDoc(doc(db, 'programs', newId), newItem);
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, `programs/${newId}`);
    }
  };

  const updateProgram = async (id: string, updated: Partial<SchoolProgram>) => {
    setPrograms(prev => prev.map(item => (item.id === id ? { ...item, ...updated } : item)));
    try {
      const existing = programs.find(p => p.id === id);
      if (existing) {
        await setDoc(doc(db, 'programs', id), { ...existing, ...updated }, { merge: true });
      }
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `programs/${id}`);
    }
  };

  const deleteProgram = async (id: string) => {
    setPrograms(prev => prev.filter(item => item.id !== id));
    try {
      await deleteDoc(doc(db, 'programs', id));
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, `programs/${id}`);
    }
  };

  // Hero Slides CRUD
  const addHeroSlide = async (slide: Omit<HeroSlide, 'id'>) => {
    const newId = 'slide-' + Date.now();
    const newItem: HeroSlide = {
      ...slide,
      id: newId
    };
    setHeroSlides(prev => [...prev, newItem]);
    try {
      await setDoc(doc(db, 'slides', newId), newItem);
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, `slides/${newId}`);
    }
  };

  const updateHeroSlide = async (id: string, updated: Partial<HeroSlide>) => {
    setHeroSlides(prev => prev.map(item => (item.id === id ? { ...item, ...updated } : item)));
    try {
      const existing = heroSlides.find(s => s.id === id);
      if (existing) {
        await setDoc(doc(db, 'slides', id), { ...existing, ...updated }, { merge: true });
      }
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `slides/${id}`);
    }
  };

  const deleteHeroSlide = async (id: string) => {
    setHeroSlides(prev => prev.filter(item => item.id !== id));
    try {
      await deleteDoc(doc(db, 'slides', id));
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, `slides/${id}`);
    }
  };

  // Categories CRUD
  const addCategory = async (cat: Omit<CategoryItem, 'id'>) => {
    const newId = 'cat-' + Date.now();
    const newItem: CategoryItem = {
      ...cat,
      id: newId
    };
    setCategories(prev => [...prev, newItem]);
    try {
      await setDoc(doc(db, 'categories', newId), newItem);
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, `categories/${newId}`);
    }
  };

  const updateCategory = async (id: string, updated: Partial<CategoryItem>) => {
    setCategories(prev => prev.map(item => (item.id === id ? { ...item, ...updated } : item)));
    try {
      const existing = categories.find(c => c.id === id);
      if (existing) {
        await setDoc(doc(db, 'categories', id), { ...existing, ...updated }, { merge: true });
      }
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `categories/${id}`);
    }
  };

  const deleteCategory = async (id: string) => {
    setCategories(prev => prev.filter(item => item.id !== id));
    try {
      await deleteDoc(doc(db, 'categories', id));
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, `categories/${id}`);
    }
  };

  // School Info & Section Texts
  const updateSchoolInfo = async (info: Partial<SchoolInfo>) => {
    const updated = { ...schoolInfo, ...info };
    setSchoolInfo(updated);
    try {
      await setDoc(doc(db, 'settings', 'schoolInfo'), updated, { merge: true });
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, 'settings/schoolInfo');
    }
  };

  const updateSectionTexts = async (texts: Partial<SectionTexts>) => {
    const updated = { ...sectionTexts, ...texts };
    setSectionTexts(updated);
    try {
      await setDoc(doc(db, 'settings', 'sectionTexts'), updated, { merge: true });
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, 'settings/sectionTexts');
    }
  };

  // Admission Inquiries
  const submitAdmissionInquiry = async (inquiry: Omit<AdmissionInquiry, 'id' | 'createdAt' | 'status'>) => {
    const newId = 'inq-' + Date.now();
    const newItem: AdmissionInquiry = {
      ...inquiry,
      id: newId,
      createdAt: new Date().toLocaleString('mn-MN'),
      status: 'new'
    };
    setInquiries(prev => [newItem, ...prev]);
    try {
      await setDoc(doc(db, 'inquiries', newId), newItem);
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, `inquiries/${newId}`);
    }
  };

  const updateInquiryStatus = async (id: string, status: AdmissionInquiry['status']) => {
    setInquiries(prev => prev.map(item => (item.id === id ? { ...item, status } : item)));
    try {
      await setDoc(doc(db, 'inquiries', id), { status }, { merge: true });
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `inquiries/${id}`);
    }
  };

  const deleteInquiry = async (id: string) => {
    setInquiries(prev => prev.filter(item => item.id !== id));
    try {
      await deleteDoc(doc(db, 'inquiries', id));
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, `inquiries/${id}`);
    }
  };

  // Academic Calendar Plan CRUD
  const addCalendarEvent = async (event: Omit<CalendarEvent, 'id'>) => {
    const newId = 'cal-' + Date.now();
    const newItem: CalendarEvent = {
      ...event,
      id: newId
    };
    setCalendarEvents(prev => [...prev, newItem]);
    try {
      await setDoc(doc(db, 'calendar', newId), newItem);
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, `calendar/${newId}`);
    }
  };

  const updateCalendarEvent = async (id: string, updated: Partial<CalendarEvent>) => {
    setCalendarEvents(prev => prev.map(item => (item.id === id ? { ...item, ...updated } : item)));
    try {
      const existing = calendarEvents.find(c => c.id === id);
      if (existing) {
        await setDoc(doc(db, 'calendar', id), { ...existing, ...updated }, { merge: true });
      }
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `calendar/${id}`);
    }
  };

  const deleteCalendarEvent = async (id: string) => {
    setCalendarEvents(prev => prev.filter(item => item.id !== id));
    try {
      await deleteDoc(doc(db, 'calendar', id));
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, `calendar/${id}`);
    }
  };

  // Reset & Backup
  const resetToDefaults = () => {
    setCategories(INITIAL_CATEGORIES);
    setHeroSlides(INITIAL_HERO_SLIDES);
    setPrograms(INITIAL_PROGRAMS);
    setNews(INITIAL_NEWS);
    setSchoolInfo(INITIAL_SCHOOL_INFO);
    setSectionTexts(INITIAL_SECTION_TEXTS);
    setInquiries(INITIAL_INQUIRIES);
    setCalendarEvents(INITIAL_CALENDAR_EVENTS);
  };

  const exportDataJson = () => {
    const fullData = {
      categories,
      heroSlides,
      programs,
      news,
      schoolInfo,
      sectionTexts,
      inquiries,
      calendarEvents,
      exportedAt: new Date().toISOString()
    };
    return JSON.stringify(fullData, null, 2);
  };

  const importDataJson = (jsonString: string): boolean => {
    try {
      const parsed = JSON.parse(jsonString);
      if (parsed.categories) setCategories(parsed.categories);
      if (parsed.heroSlides) setHeroSlides(parsed.heroSlides);
      if (parsed.programs) setPrograms(parsed.programs);
      if (parsed.news) setNews(parsed.news);
      if (parsed.schoolInfo) setSchoolInfo(parsed.schoolInfo);
      if (parsed.sectionTexts) setSectionTexts(parsed.sectionTexts);
      if (parsed.inquiries) setInquiries(parsed.inquiries);
      if (parsed.calendarEvents) setCalendarEvents(parsed.calendarEvents);
      return true;
    } catch (e) {
      console.error('Failed to parse import JSON', e);
      return false;
    }
  };

  return (
    <SchoolContext.Provider
      value={{
        categories,
        heroSlides,
        programs,
        news,
        schoolInfo,
        sectionTexts,
        inquiries,
        calendarEvents,
        activeCategory,
        selectedProgramModal,
        selectedNewsModal,
        isAdmissionModalOpen,
        isAdminOpen,
        isAdminLoginModalOpen,
        isAdminAuthenticated,
        adminUsername,
        searchQuery,
        isFirebaseConnected,
        setActiveCategory,
        setSelectedProgramModal,
        setSelectedNewsModal,
        setIsAdmissionModalOpen,
        setIsAdminOpen,
        setIsAdminLoginModalOpen,
        openAdmin,
        setSearchQuery,
        loginAdmin,
        logoutAdmin,
        updateAdminCredentials,
        addNewsArticle,
        updateNewsArticle,
        deleteNewsArticle,
        addProgram,
        updateProgram,
        deleteProgram,
        addHeroSlide,
        updateHeroSlide,
        deleteHeroSlide,
        addCategory,
        updateCategory,
        deleteCategory,
        updateSchoolInfo,
        updateSectionTexts,
        submitAdmissionInquiry,
        updateInquiryStatus,
        deleteInquiry,
        addCalendarEvent,
        updateCalendarEvent,
        deleteCalendarEvent,
        resetToDefaults,
        exportDataJson,
        importDataJson
      }}
    >
      {children}
    </SchoolContext.Provider>
  );
};

export const useSchool = () => {
  const context = useContext(SchoolContext);
  if (!context) {
    throw new Error('useSchool must be used within a SchoolProvider');
  }
  return context;
};

