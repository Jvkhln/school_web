/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { SchoolProvider, useSchool } from './context/SchoolContext';
import { Header } from './components/Header';
import { HeroSlider } from './components/HeroSlider';
import { CategoryIconBar } from './components/CategoryIconBar';
import { FeaturedPrograms } from './components/FeaturedPrograms';
import { StatsSection } from './components/StatsSection';
import { NewsSection } from './components/NewsSection';
import { AboutSection } from './components/AboutSection';
import { Footer } from './components/Footer';
import { ProgramDetailModal } from './components/Modals/ProgramDetailModal';
import { NewsDetailModal } from './components/Modals/NewsDetailModal';
import { FeedbackModal } from './components/Modals/FeedbackModal';
import { AdminLoginModal } from './components/Admin/AdminLoginModal';
import { AdminDashboard } from './components/Admin/AdminDashboard';

const MainLayout: React.FC = () => {
  const { isAdminOpen } = useSchool();

  if (isAdminOpen) {
    return (
      <>
        <AdminDashboard />
        <AdminLoginModal />
      </>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#fafafa] text-slate-800 selection:bg-amber-100 selection:text-amber-900">
      {/* Top Navigation */}
      <Header />

      {/* Main Content Area */}
      <main className="flex-1">
        {/* 1. Hero Slider Banner matching screenshot */}
        <HeroSlider />

        {/* 2. Horizontal Category Feature Icons matching screenshot */}
        <CategoryIconBar />

        {/* 3. Explore Top Programs Grid (3 top, 2 bottom) matching screenshot */}
        <FeaturedPrograms />

        {/* 4. Stats Counter Bar */}
        <StatsSection />

        {/* 5. Stay Updated with Latest News (3-column cards) matching screenshot */}
        <NewsSection />

        {/* 6. About the School & Core Values */}
        <AboutSection />
      </main>

      {/* 7. Warm 4-Column Branded Footer matching screenshot palette */}
      <Footer />

      {/* Modals */}
      <ProgramDetailModal />
      <NewsDetailModal />
      <FeedbackModal />
      <AdminLoginModal />
    </div>
  );
};

export default function App() {
  return (
    <SchoolProvider>
      <MainLayout />
    </SchoolProvider>
  );
}
