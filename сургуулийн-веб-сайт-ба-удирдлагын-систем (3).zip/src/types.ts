export type CategoryType = 
  | 'primary'
  | 'middle'
  | 'high'
  | 'stem'
  | 'language'
  | 'arts_sports'
  | 'olympiad'
  | 'general';

export interface CategoryItem {
  id: string;
  name: string;
  nameEn: string;
  slug: string;
  iconName: string;
  description: string;
  count?: number;
}

export interface HeroSlide {
  id: string;
  title: string;
  subtitle: string;
  imageUrl: string;
  buttonText: string;
  buttonLink: string;
  badge?: string;
  active: boolean;
  order: number;
}

export interface SchoolProgram {
  id: string;
  title: string;
  subtitle: string;
  categorySlug: string;
  categoryName: string;
  imageUrl: string;
  tags: string[];
  description: string;
  features: string[];
  curriculum?: string;
  ageRange?: string;
  schedule?: string;
  featured?: boolean;
  order: number;
  createdAt: string;
}

export interface NewsArticle {
  id: string;
  title: string;
  slug: string;
  categorySlug: string;
  categoryName: string;
  date: string;
  excerpt: string;
  content: string;
  imageUrl: string;
  author: string;
  views: number;
  featured: boolean;
  tags?: string[];
  createdAt: string;
}

export interface SchoolInfo {
  name: string;
  logoUrl?: string;
  motto: string;
  description: string;
  phone: string;
  email: string;
  address: string;
  city: string;
  workingHours: string;
  facebookUrl: string;
  instagramUrl: string;
  youtubeUrl: string;
  studentsCount: number;
  teachersCount: number;
  collegeAcceptanceRate: number;
  clubsCount: number;
}

export interface AdmissionInquiry {
  id: string;
  name: string; // sender name
  phone: string;
  email?: string;
  type: 'feedback' | 'admission' | 'question' | 'complaint'; // төрөл
  subject?: string;
  message: string; // санал хүсэлтийн агуулга
  studentName?: string;
  parentName?: string;
  gradeLevel?: string;
  programInterest?: string;
  notes?: string;
  createdAt: string;
  status: 'new' | 'contacted' | 'approved' | 'rejected';
}

export interface CalendarEvent {
  id: string;
  title: string;
  month: string; // e.g. "2025-03"
  monthName: string; // e.g. "3-р сар"
  day: string; // e.g. "15" or "20-22"
  dateRange: string; // e.g. "2025.03.15"
  category: 'exam' | 'event' | 'holiday' | 'meeting' | 'olympiad' | 'admission';
  categoryName: string; // "Улирлын шалгалт", "Сургуулийн арга хэмжээ", "Амралт", "Хурал", "Олимпиад", "Элсэлт"
  targetGroup: string; // "Бүх анги", "1-5-р анги", "6-9-р анги", "10-12-р анги", "Эцэг эхчүүд"
  description?: string;
  location?: string;
  isImportant?: boolean;
}

export interface SectionTexts {
  topAnnouncement?: string;
  programsTitle: string;
  programsSubtitle: string;
  newsTitle: string;
  newsSubtitle: string;
  aboutBadge: string;
  aboutTitle: string;
  aboutDescription: string;
  aboutMissionQuote: string;
  aboutStatValue: string;
  aboutStatLabel: string;
  footerDescription: string;
  admissionModalTitle: string;
  admissionModalSubtitle: string;
}
