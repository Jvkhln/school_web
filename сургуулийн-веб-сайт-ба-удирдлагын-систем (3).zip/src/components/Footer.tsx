import React from 'react';
import { useSchool } from '../context/SchoolContext';
import {
  School,
  MapPin,
  Mail,
  Phone,
  Clock,
  Facebook,
  Instagram,
  Youtube,
  ShieldCheck,
  MessageSquarePlus
} from 'lucide-react';

export const Footer: React.FC = () => {
  const { schoolInfo, sectionTexts, categories, setActiveCategory, openAdmin, setIsAdmissionModalOpen } =
    useSchool();

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer id="contact" className="bg-[#c85a17] text-amber-50">
      {/* Main Footer Container matching the screenshot's warm color and columns */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-8">
          {/* Column 1: School Identity & Mission */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-white text-[#c85a17] flex items-center justify-center font-bold shadow-xs overflow-hidden">
                {schoolInfo.logoUrl ? (
                  <img
                    src={schoolInfo.logoUrl}
                    alt={schoolInfo.name}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <School className="w-6 h-6" />
                )}
              </div>
              <span className="font-extrabold text-xl tracking-tight text-white">
                {schoolInfo.name}
              </span>
            </div>

            <p className="text-xs sm:text-sm text-amber-100/90 leading-relaxed max-w-sm">
              {sectionTexts.footerDescription}
            </p>

            {/* Join Us / Social Links */}
            <div className="pt-2">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
                Биднийг дагаарай
              </h4>
              <div className="flex items-center space-x-3 text-white">
                <a
                  href={schoolInfo.facebookUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="w-8 h-8 rounded-full bg-white/15 hover:bg-white hover:text-[#c85a17] transition-all flex items-center justify-center"
                  aria-label="Facebook"
                >
                  <Facebook className="w-4 h-4" />
                </a>
                <a
                  href={schoolInfo.instagramUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="w-8 h-8 rounded-full bg-white/15 hover:bg-white hover:text-[#c85a17] transition-all flex items-center justify-center"
                  aria-label="Instagram"
                >
                  <Instagram className="w-4 h-4" />
                </a>
                <a
                  href={schoolInfo.youtubeUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="w-8 h-8 rounded-full bg-white/15 hover:bg-white hover:text-[#c85a17] transition-all flex items-center justify-center"
                  aria-label="YouTube"
                >
                  <Youtube className="w-4 h-4" />
                </a>
              </div>
            </div>
          </div>

          {/* Column 2: Categories / Programs */}
          <div className="space-y-4">
            <h3 className="font-bold text-base text-white tracking-wide">
              Сургалтын хөтөлбөр
            </h3>
            <ul className="space-y-2.5 text-xs sm:text-sm text-amber-100/90">
              {categories.slice(0, 6).map((cat) => (
                <li key={cat.id}>
                  <button
                    onClick={() => {
                      setActiveCategory(cat.slug);
                      scrollToSection('programs');
                    }}
                    className="hover:text-white hover:underline transition-all text-left"
                  >
                    {cat.name}
                  </button>
                </li>
              ))}
              <li>
                <button
                  onClick={() => {
                    setActiveCategory('all');
                    scrollToSection('programs');
                  }}
                  className="text-amber-200 font-semibold hover:underline"
                >
                  Бүх хөтөлбөрийг харах →
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Parents & Students Services */}
          <div className="space-y-4">
            <h3 className="font-bold text-base text-white tracking-wide">
              Эцэг эх, сурагчдад
            </h3>
            <ul className="space-y-2.5 text-xs sm:text-sm text-amber-100/90">
              <li>
                <button
                  onClick={() => setIsAdmissionModalOpen(true)}
                  className="hover:text-white hover:underline cursor-pointer flex items-center gap-1.5 text-amber-200 font-bold bg-black/15 px-2.5 py-1.5 rounded-lg border border-amber-300/30"
                >
                  <MessageSquarePlus className="w-3.5 h-3.5" />
                  <span>Санал хүсэлт илгээх</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection('news')}
                  className="hover:text-white hover:underline"
                >
                  Сургуулийн зар мэдээ
                </button>
              </li>
              <li>
                <span className="hover:text-white cursor-pointer">Цахим журнал & Ирц</span>
              </li>
              <li>
                <span className="hover:text-white cursor-pointer">Хичээлийн хуваарь & Календарь</span>
              </li>
              <li>
                <span className="hover:text-white cursor-pointer">Үдийн цай, хоолны цэс</span>
              </li>
              <li>
                <span className="hover:text-white cursor-pointer">Сургуулийн дүрэм, стандарт</span>
              </li>
              <li>
                <button
                  onClick={openAdmin}
                  className="inline-flex items-center gap-1 text-amber-200 font-semibold hover:underline"
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Админ удирдлагын хэсэг</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Column 4: Contact Us */}
          <div className="space-y-4">
            <h3 className="font-bold text-base text-white tracking-wide">
              Холбоо барих
            </h3>
            <div className="space-y-3 text-xs sm:text-sm text-amber-100/90">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-amber-200 shrink-0 mt-0.5" />
                <span>{schoolInfo.address}</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-amber-200 shrink-0" />
                <a href={`mailto:${schoolInfo.email}`} className="hover:underline text-white">
                  {schoolInfo.email}
                </a>
              </div>
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-amber-200 shrink-0" />
                <a href={`tel:${schoolInfo.phone}`} className="hover:underline font-semibold text-white">
                  {schoolInfo.phone}
                </a>
              </div>
              <div className="flex items-start gap-2.5">
                <Clock className="w-4 h-4 text-amber-200 shrink-0 mt-0.5" />
                <span className="text-[11px]">{schoolInfo.workingHours}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Sub-footer line matching screenshot */}
      <div className="border-t border-amber-800/60 bg-[#b95112] py-4 px-4 sm:px-6 lg:px-8 text-xs text-amber-200/80">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 text-center sm:text-left">
          <p>© {new Date().getFullYear()} "{schoolInfo.name}". Бүх эрх хуулиар хамгаалагдсан.</p>
          <p className="text-amber-200/60">
            Сургуулийн танилцуулга & Админ контент удирдлагын систем
          </p>
        </div>
      </div>
    </footer>
  );
};
