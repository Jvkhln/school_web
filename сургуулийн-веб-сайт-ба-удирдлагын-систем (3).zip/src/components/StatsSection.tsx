import React from 'react';
import { useSchool } from '../context/SchoolContext';
import { Users, Award, GraduationCap, Sparkles, BookOpen, ShieldCheck } from 'lucide-react';

export const StatsSection: React.FC = () => {
  const { schoolInfo } = useSchool();

  const stats = [
    {
      label: 'Нийт суралцагч сурагчид',
      value: `${schoolInfo.studentsCount}+`,
      icon: Users,
      desc: '1-12-р ангийн шилдэг сурагчид'
    },
    {
      label: 'Багшлах бүрэлдэхүүн',
      value: `${schoolInfo.teachersCount}+`,
      icon: GraduationCap,
      desc: 'Магистр, Доктор, Олон улсын зэрэгтэй'
    },
    {
      label: 'Их дээд сургуулийн элсэлт',
      value: `${schoolInfo.collegeAcceptanceRate}%`,
      icon: Award,
      desc: 'Дэлхийн шилдэг болон дотоодын тэтгэлэг'
    },
    {
      label: 'Хөгжлийн дугуйлан, клубүүд',
      value: `${schoolInfo.clubsCount}+`,
      icon: Sparkles,
      desc: 'STEM, Урлаг, Спорт, Гадаад хэл'
    }
  ];

  return (
    <section className="bg-slate-900 text-white py-14 px-4 sm:px-6 lg:px-8 border-y border-slate-800">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {stats.map((stat, idx) => {
            const Icon = stat.icon;
            return (
              <div
                key={idx}
                className="flex flex-col items-center text-center p-4 rounded-xl bg-slate-800/40 border border-slate-700/60 hover:border-amber-500/50 transition-colors"
              >
                <div className="w-12 h-12 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center mb-3">
                  <Icon className="w-6 h-6" />
                </div>
                <div className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight mb-1">
                  {stat.value}
                </div>
                <div className="text-xs sm:text-sm font-semibold text-amber-400 mb-1">
                  {stat.label}
                </div>
                <p className="text-[11px] text-slate-400 max-w-[180px] hidden sm:block">
                  {stat.desc}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
