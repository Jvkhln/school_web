import React, { useState, useMemo } from 'react';
import { useSchool } from '../context/SchoolContext';
import { CalendarEvent } from '../types';
import {
  Calendar,
  Clock,
  MapPin,
  Users,
  ChevronRight,
  ChevronLeft,
  Sparkles,
  CalendarDays,
  Tag,
  AlertCircle,
  PlusCircle,
  CheckCircle2,
  Info,
  SlidersHorizontal,
  FileSpreadsheet
} from 'lucide-react';

export const CalendarSidebar: React.FC = () => {
  const {
    calendarEvents,
    isAdminAuthenticated,
    openAdmin,
    setIsAdminOpen
  } = useSchool();

  const [activeMonthFilter, setActiveMonthFilter] = useState<'upcoming' | string>('upcoming');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedEvent, setSelectedEvent] = useState<CalendarEvent | null>(null);

  // Extract distinct months present in the calendar events, sorted
  const availableMonths = useMemo(() => {
    const monthsMap = new Map<string, string>();
    calendarEvents.forEach((ev) => {
      if (ev.month) {
        monthsMap.set(ev.month, ev.monthName || ev.month);
      }
    });
    return Array.from(monthsMap.entries()).sort((a, b) => a[0].localeCompare(b[0]));
  }, [calendarEvents]);

  // Determine the next 1-2 upcoming months (e.g. current month 03 and next 04)
  const upcomingMonths = useMemo(() => {
    if (availableMonths.length <= 2) {
      return availableMonths.map(([m]) => m);
    }
    // Return first 2 available sorted months as upcoming window
    return availableMonths.slice(0, 2).map(([m]) => m);
  }, [availableMonths]);

  // Filter events based on active month filter and category
  const filteredEvents = useMemo(() => {
    return calendarEvents.filter((ev) => {
      // Month match
      let matchesMonth = true;
      if (activeMonthFilter === 'upcoming') {
        matchesMonth = upcomingMonths.includes(ev.month);
      } else if (activeMonthFilter !== 'all') {
        matchesMonth = ev.month === activeMonthFilter;
      }

      // Category match
      let matchesCategory = true;
      if (selectedCategory !== 'all') {
        matchesCategory = ev.category === selectedCategory;
      }

      return matchesMonth && matchesCategory;
    }).sort((a, b) => {
      // Sort by month then day
      if (a.month !== b.month) return a.month.localeCompare(b.month);
      return a.day.localeCompare(b.day);
    });
  }, [calendarEvents, activeMonthFilter, selectedCategory, upcomingMonths]);

  // Category visual styles
  const getCategoryStyles = (category: CalendarEvent['category']) => {
    switch (category) {
      case 'exam':
        return {
          badge: 'bg-rose-100 text-rose-800 border-rose-200',
          dot: 'bg-rose-500',
          dayBg: 'bg-rose-50 border-rose-200 text-rose-900',
          indicator: 'border-l-rose-500'
        };
      case 'holiday':
        return {
          badge: 'bg-emerald-100 text-emerald-800 border-emerald-200',
          dot: 'bg-emerald-500',
          dayBg: 'bg-emerald-50 border-emerald-200 text-emerald-900',
          indicator: 'border-l-emerald-500'
        };
      case 'olympiad':
        return {
          badge: 'bg-indigo-100 text-indigo-800 border-indigo-200',
          dot: 'bg-indigo-500',
          dayBg: 'bg-indigo-50 border-indigo-200 text-indigo-900',
          indicator: 'border-l-indigo-500'
        };
      case 'admission':
        return {
          badge: 'bg-amber-100 text-amber-900 border-amber-300',
          dot: 'bg-amber-500',
          dayBg: 'bg-amber-50 border-amber-200 text-amber-950',
          indicator: 'border-l-amber-500'
        };
      case 'meeting':
        return {
          badge: 'bg-purple-100 text-purple-800 border-purple-200',
          dot: 'bg-purple-500',
          dayBg: 'bg-purple-50 border-purple-200 text-purple-900',
          indicator: 'border-l-purple-500'
        };
      default:
        return {
          badge: 'bg-blue-100 text-blue-800 border-blue-200',
          dot: 'bg-blue-500',
          dayBg: 'bg-blue-50 border-blue-200 text-blue-900',
          indicator: 'border-l-blue-500'
        };
    }
  };

  return (
    <div className="bg-slate-50/90 border border-slate-200/90 rounded-3xl p-4 sm:p-6 shadow-xs flex flex-col h-full relative lg:sticky lg:top-24">
      {/* Sidebar Header */}
      <div className="flex items-center justify-between gap-3 pb-4 border-b border-slate-200/80">
        <div className="flex items-center gap-2.5 sm:gap-3">
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-600 text-white flex items-center justify-center shadow-md shadow-amber-500/20 shrink-0">
            <CalendarDays className="w-4 h-4 sm:w-5 sm:h-5" />
          </div>
          <div>
            <h3 className="font-extrabold text-slate-900 text-sm sm:text-base lg:text-lg leading-tight flex items-center gap-1.5">
              <span>Хуанли & Төлөвлөгөө</span>
              <span className="inline-block w-2 h-2 rounded-full bg-amber-500 animate-pulse"></span>
            </h3>
            <p className="text-[11px] sm:text-xs text-slate-500 font-medium">
              2025-2026 Оны сургалтын төлөвлөгөө
            </p>
          </div>
        </div>

        {isAdminAuthenticated && (
          <button
            onClick={() => setIsAdminOpen(true)}
            className="text-[10px] sm:text-[11px] font-bold bg-amber-100 hover:bg-amber-200 text-amber-900 px-2 sm:px-2.5 py-1 rounded-lg transition-all flex items-center gap-1 border border-amber-300 shrink-0 cursor-pointer"
            title="Төлөвлөгөө засах / нэмэх"
          >
            <PlusCircle className="w-3 h-3 text-amber-700" />
            <span>Засах</span>
          </button>
        )}
      </div>

      {/* Month Slide / Tab Bar */}
      <div className="pt-3 sm:pt-4 pb-2 sm:pb-3">
        <div className="text-[10px] sm:text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2 flex items-center justify-between">
          <span>Сар сонгох:</span>
          <span className="text-[10px] text-amber-700 font-semibold bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200/60 truncate max-w-[140px]">
            {activeMonthFilter === 'upcoming'
              ? 'Сүүлийн 1-2 сар'
              : activeMonthFilter === 'all'
              ? 'Бүх сар'
              : availableMonths.find(([m]) => m === activeMonthFilter)?.[1] || activeMonthFilter}
          </span>
        </div>

        {/* Scrollable / Sliding Month Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1.5 pt-0.5 scrollbar-none no-scrollbar">
          <button
            onClick={() => setActiveMonthFilter('upcoming')}
            className={`px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer flex items-center gap-1 shrink-0 ${
              activeMonthFilter === 'upcoming'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-white text-slate-700 hover:bg-slate-200/70 border border-slate-200'
            }`}
          >
            <Sparkles className="w-3 h-3" />
            <span>Сүүлийн 1-2 сар</span>
          </button>

          {availableMonths.map(([mCode, mName]) => (
            <button
              key={mCode}
              onClick={() => setActiveMonthFilter(mCode)}
              className={`px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer shrink-0 ${
                activeMonthFilter === mCode
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-white text-slate-700 hover:bg-slate-200/70 border border-slate-200'
              }`}
            >
              {mName}
            </button>
          ))}

          <button
            onClick={() => setActiveMonthFilter('all')}
            className={`px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer shrink-0 ${
              activeMonthFilter === 'all'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-white text-slate-700 hover:bg-slate-200/70 border border-slate-200'
            }`}
          >
            Бүгд ({calendarEvents.length})
          </button>
        </div>
      </div>

      {/* Category Mini Filters */}
      <div className="flex flex-wrap items-center gap-1 pb-3 mb-2 border-b border-slate-200/60 text-[11px]">
        {[
          { id: 'all', label: 'Бүх төрөл' },
          { id: 'exam', label: 'Шалгалт' },
          { id: 'event', label: 'Арга хэмжээ' },
          { id: 'holiday', label: 'Амралт' },
          { id: 'olympiad', label: 'Олимпиад' }
        ].map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-2 py-0.5 rounded-md font-semibold transition-colors cursor-pointer ${
              selectedCategory === cat.id
                ? 'bg-slate-800 text-white'
                : 'text-slate-600 hover:bg-slate-200/80 bg-white/70'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Events List / Timeline Display */}
      <div className="flex-1 overflow-y-auto max-h-[460px] pr-1 space-y-3 scrollbar-thin">
        {filteredEvents.length === 0 ? (
          <div className="text-center py-10 px-4 bg-white/60 rounded-2xl border border-dashed border-slate-300">
            <Calendar className="w-8 h-8 text-slate-400 mx-auto mb-2" />
            <p className="text-xs font-semibold text-slate-700 mb-1">
              Энэ хугацаанд төлөвлөгөө бүртгэгдээгүй байна
            </p>
            <p className="text-[11px] text-slate-500 mb-3">
              Өөр сар сонгох эсвэл бүх төлөвлөгөөг харна уу.
            </p>
            <button
              onClick={() => {
                setActiveMonthFilter('all');
                setSelectedCategory('all');
              }}
              className="text-xs bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-3 py-1.5 rounded-lg transition-all cursor-pointer"
            >
              Бүх төлөвлөгөөг харах
            </button>
          </div>
        ) : (
          filteredEvents.map((ev) => {
            const styles = getCategoryStyles(ev.category);
            return (
              <div
                key={ev.id}
                id={`calendar-event-${ev.id}`}
                onClick={() => setSelectedEvent(ev)}
                className="group relative bg-white hover:bg-amber-50/40 p-3.5 rounded-2xl border border-slate-200/80 hover:border-amber-400/80 shadow-2xs hover:shadow-sm transition-all duration-200 cursor-pointer"
              >
                <div className="flex items-start gap-3">
                  {/* Day / Month Badge */}
                  <div
                    className={`w-12 sm:w-14 h-12 sm:h-14 rounded-xl border flex flex-col items-center justify-center shrink-0 shadow-2xs ${styles.dayBg}`}
                  >
                    <span className="text-[10px] uppercase font-extrabold tracking-tight text-slate-600 leading-none">
                      {ev.monthName || ev.month.slice(-2) + '-р сар'}
                    </span>
                    <span className="text-sm sm:text-base font-black leading-tight tracking-tight mt-0.5">
                      {ev.day}
                    </span>
                  </div>

                  {/* Event Details */}
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-1.5 mb-1">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${styles.badge}`}
                      >
                        {ev.categoryName}
                      </span>
                      {ev.targetGroup && (
                        <span className="text-[10px] font-medium text-slate-600 bg-slate-100 px-2 py-0.5 rounded-md flex items-center gap-1">
                          <Users className="w-2.5 h-2.5 text-slate-400" />
                          <span>{ev.targetGroup}</span>
                        </span>
                      )}
                      {ev.isImportant && (
                        <span className="text-[9px] font-bold text-amber-800 bg-amber-100/90 px-1.5 py-0.5 rounded border border-amber-300">
                          Онцлох
                        </span>
                      )}
                    </div>

                    <h4 className="font-bold text-xs sm:text-sm text-slate-900 group-hover:text-amber-700 transition-colors leading-snug line-clamp-2">
                      {ev.title}
                    </h4>

                    {ev.description && (
                      <p className="text-[11px] text-slate-500 mt-1 line-clamp-1">
                        {ev.description}
                      </p>
                    )}

                    {ev.location && (
                      <div className="flex items-center gap-1 text-[10px] text-slate-400 mt-1">
                        <MapPin className="w-2.5 h-2.5 text-slate-400" />
                        <span className="truncate">{ev.location}</span>
                      </div>
                    )}
                  </div>

                  <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-amber-600 group-hover:translate-x-0.5 transition-all self-center shrink-0" />
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Footer Summary / Quick Note */}
      <div className="pt-3 mt-3 border-t border-slate-200/80 flex items-center justify-between text-[11px] text-slate-500">
        <div className="flex items-center gap-1">
          <Info className="w-3.5 h-3.5 text-amber-600" />
          <span>Нийт {calendarEvents.length} төлөвлөгөөт үйл явдал</span>
        </div>

        <button
          onClick={() => setActiveMonthFilter('all')}
          className="font-bold text-amber-700 hover:text-amber-900 underline cursor-pointer"
        >
          Бүх төлөвлөгөө
        </button>
      </div>

      {/* Selected Event Popup Modal */}
      {selectedEvent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-150">
          <div
            className="bg-white w-full max-w-md rounded-3xl border border-slate-200 shadow-2xl p-6 relative space-y-4 animate-in zoom-in-95 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex items-start justify-between gap-3 border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold shadow-xs">
                  <Calendar className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[11px] font-bold text-amber-700 uppercase tracking-wider">
                    {selectedEvent.monthName} • {selectedEvent.categoryName}
                  </span>
                  <h3 className="font-extrabold text-slate-900 text-base sm:text-lg leading-tight">
                    {selectedEvent.title}
                  </h3>
                </div>
              </div>

              <button
                onClick={() => setSelectedEvent(null)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Modal Body */}
            <div className="space-y-3 text-xs sm:text-sm text-slate-700">
              <div className="grid grid-cols-2 gap-2 bg-slate-50 p-3 rounded-2xl border border-slate-200/60">
                <div>
                  <span className="text-[10px] text-slate-400 font-bold block uppercase">
                    Хугацаа
                  </span>
                  <span className="font-bold text-slate-900">
                    {selectedEvent.dateRange || `${selectedEvent.monthName} ${selectedEvent.day}`}
                  </span>
                </div>

                <div>
                  <span className="text-[10px] text-slate-400 font-bold block uppercase">
                    Хамаарах бүлэг
                  </span>
                  <span className="font-bold text-slate-900">
                    {selectedEvent.targetGroup || 'Бүх сурагчид'}
                  </span>
                </div>
              </div>

              {selectedEvent.location && (
                <div className="flex items-center gap-2 bg-amber-50/60 text-amber-950 p-2.5 rounded-xl border border-amber-200/60 text-xs">
                  <MapPin className="w-4 h-4 text-amber-600 shrink-0" />
                  <span className="font-medium">Байршил: {selectedEvent.location}</span>
                </div>
              )}

              {selectedEvent.description && (
                <div className="space-y-1">
                  <span className="text-[11px] font-bold text-slate-500 uppercase block">
                    Дэлгэрэнгүй тайлбар
                  </span>
                  <p className="text-slate-600 leading-relaxed bg-slate-50/80 p-3 rounded-xl border border-slate-100">
                    {selectedEvent.description}
                  </p>
                </div>
              )}
            </div>

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              {isAdminAuthenticated && (
                <button
                  onClick={() => {
                    setSelectedEvent(null);
                    setIsAdminOpen(true);
                  }}
                  className="bg-amber-100 hover:bg-amber-200 text-amber-900 font-bold text-xs px-4 py-2 rounded-xl transition-all cursor-pointer"
                >
                  Админ самбарт засах
                </button>
              )}
              <button
                onClick={() => setSelectedEvent(null)}
                className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs px-5 py-2 rounded-xl shadow-xs transition-all cursor-pointer"
              >
                Хаах
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
