import React, { useState } from 'react';
import { useSchool } from '../../context/SchoolContext';
import {
  X,
  CheckCircle2,
  MessageSquarePlus,
  Send,
  Sparkles,
  Phone,
  User,
  Mail,
  HelpCircle,
  AlertTriangle,
  GraduationCap,
  MessageCircle
} from 'lucide-react';

export const FeedbackModal: React.FC = () => {
  const {
    isAdmissionModalOpen,
    setIsAdmissionModalOpen,
    submitAdmissionInquiry,
    programs,
    categories
  } = useSchool();

  // Form type: feedback, question, admission, complaint
  const [feedbackType, setFeedbackType] = useState<'feedback' | 'admission' | 'question' | 'complaint'>('feedback');
  
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    subject: '',
    message: '',
    gradeLevel: '1-р анги',
    programInterest: 'Ерөнхий боловсрол'
  });
  
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  if (!isAdmissionModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.phone.trim() || !formData.message.trim()) return;

    setLoading(true);

    setTimeout(() => {
      submitAdmissionInquiry({
        name: formData.name.trim(),
        studentName: formData.name.trim(),
        parentName: formData.name.trim(),
        phone: formData.phone.trim(),
        email: formData.email.trim() || undefined,
        type: feedbackType,
        subject: formData.subject.trim() || (feedbackType === 'feedback' ? 'Санал хүсэлт' : feedbackType === 'question' ? 'Асуулт лавлагаа' : feedbackType === 'admission' ? 'Элсэлтийн сорилт' : 'Гомдол санал'),
        message: formData.message.trim(),
        gradeLevel: feedbackType === 'admission' ? formData.gradeLevel : undefined,
        programInterest: feedbackType === 'admission' ? formData.programInterest : undefined,
        notes: formData.message.trim()
      });

      setLoading(false);
      setSubmitted(true);

      setTimeout(() => {
        setSubmitted(false);
        setIsAdmissionModalOpen(false);
        setFormData({
          name: '',
          phone: '',
          email: '',
          subject: '',
          message: '',
          gradeLevel: '1-р анги',
          programInterest: 'Ерөнхий боловсрол'
        });
      }, 2500);
    }, 300);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
      <div
        className="relative bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-100 p-6 sm:p-8 flex flex-col animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={() => {
            setIsAdmissionModalOpen(false);
            setSubmitted(false);
          }}
          className="absolute top-4 right-4 w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center transition-colors cursor-pointer"
          title="Хаах"
        >
          <X className="w-5 h-5" />
        </button>

        {submitted ? (
          <div className="py-10 text-center space-y-4">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-md">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold text-slate-900">
              Таны санал хүсэлтийг амжилттай хүлээн авлаа!
            </h3>
            <p className="text-sm text-slate-600 max-w-xs mx-auto">
              Бид таны илгээсэн санал хүсэлттэй танилцаж, шаардлагатай бол холбогдох утсаар эргэн холбогдох болно. Баярлалаа!
            </p>
          </div>
        ) : (
          <div>
            {/* Header */}
            <div className="flex items-center gap-3 mb-4">
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 text-slate-950 flex items-center justify-center shadow-md shadow-amber-500/20">
                <MessageSquarePlus className="w-6 h-6 stroke-[2.2]" />
              </div>
              <div>
                <h3 className="text-lg sm:text-xl font-extrabold text-slate-900 leading-tight flex items-center gap-2">
                  <span>Санал, Хүсэлт Илгээх</span>
                  <span className="relative flex h-2.5 w-2.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500"></span>
                  </span>
                </h3>
                <span className="text-xs text-slate-500 font-medium">
                  Сургуулийн удирдлагад санал, хүсэлт, асуултаа шууд илгээнэ үү
                </span>
              </div>
            </div>

            {/* Type selector tabs */}
            <div className="grid grid-cols-4 gap-1.5 p-1 bg-slate-100 rounded-2xl mb-5 text-xs font-bold">
              <button
                type="button"
                onClick={() => setFeedbackType('feedback')}
                className={`py-2 px-1 rounded-xl transition-all flex flex-col sm:flex-row items-center justify-center gap-1 cursor-pointer ${
                  feedbackType === 'feedback'
                    ? 'bg-amber-400 text-slate-950 shadow-xs font-extrabold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span className="truncate">Санал хүсэлт</span>
              </button>

              <button
                type="button"
                onClick={() => setFeedbackType('question')}
                className={`py-2 px-1 rounded-xl transition-all flex flex-col sm:flex-row items-center justify-center gap-1 cursor-pointer ${
                  feedbackType === 'question'
                    ? 'bg-amber-400 text-slate-950 shadow-xs font-extrabold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span className="truncate">Асуулт</span>
              </button>

              <button
                type="button"
                onClick={() => setFeedbackType('admission')}
                className={`py-2 px-1 rounded-xl transition-all flex flex-col sm:flex-row items-center justify-center gap-1 cursor-pointer ${
                  feedbackType === 'admission'
                    ? 'bg-amber-400 text-slate-950 shadow-xs font-extrabold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                <GraduationCap className="w-3.5 h-3.5" />
                <span className="truncate">Элсэлт</span>
              </button>

              <button
                type="button"
                onClick={() => setFeedbackType('complaint')}
                className={`py-2 px-1 rounded-xl transition-all flex flex-col sm:flex-row items-center justify-center gap-1 cursor-pointer ${
                  feedbackType === 'complaint'
                    ? 'bg-amber-400 text-slate-950 shadow-xs font-extrabold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                <AlertTriangle className="w-3.5 h-3.5" />
                <span className="truncate">Шүүмж</span>
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3.5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Таны нэр *
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                    <input
                      type="text"
                      required
                      placeholder="Нэрээ оруулна уу"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Утасны дугаар *
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                    <input
                      type="tel"
                      required
                      placeholder="9911-XXXX"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Имэйл хаяг (сонголтоор)
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                    <input
                      type="email"
                      placeholder="name@example.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Гарчиг / Сэдэв
                  </label>
                  <input
                    type="text"
                    placeholder="Жишээ: Сургалтын талаар"
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500"
                  />
                </div>
              </div>

              {feedbackType === 'admission' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-amber-50/70 border border-amber-200 rounded-2xl animate-in fade-in">
                  <div>
                    <label className="block text-xs font-bold text-amber-900 mb-1">
                      Элсэх анги
                    </label>
                    <select
                      value={formData.gradeLevel}
                      onChange={(e) => setFormData({ ...formData, gradeLevel: e.target.value })}
                      className="w-full px-3 py-1.5 text-xs bg-white border border-amber-300 rounded-xl focus:outline-hidden"
                    >
                      <option value="1-р анги">1-р анги</option>
                      <option value="2-5-р анги">2-5-р анги (Бага)</option>
                      <option value="6-9-р анги">6-9-р анги (Дунд)</option>
                      <option value="10-12-р анги">10-12-р анги (Ахлах)</option>
                      <option value="Бэлтгэл бүлэг">Бэлтгэл бүлэг</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-amber-900 mb-1">
                      Сонирхож буй хөтөлбөр
                    </label>
                    <select
                      value={formData.programInterest}
                      onChange={(e) => setFormData({ ...formData, programInterest: e.target.value })}
                      className="w-full px-3 py-1.5 text-xs bg-white border border-amber-300 rounded-xl focus:outline-hidden"
                    >
                      {programs.map((p) => (
                        <option key={p.id} value={p.title}>
                          {p.title}
                        </option>
                      ))}
                      <option value="Ерөнхий боловсрол">Ерөнхий боловсрол</option>
                    </select>
                  </div>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Санал хүсэлтийн дэлгэрэнгүй агуулга *
                </label>
                <textarea
                  rows={4}
                  required
                  placeholder="Сургуулийн үйл ажиллагаа, сургалт, орчин нөхцөлтэй холбоотой санал, асуултаа энд бичнэ үү..."
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500"
                ></textarea>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 bg-amber-400 hover:bg-amber-300 active:scale-98 text-slate-950 font-extrabold text-sm rounded-xl shadow-md hover:shadow-amber-400/30 transition-all flex items-center justify-center gap-2 cursor-pointer border border-amber-300 ring-2 ring-amber-400/30 disabled:opacity-50"
                >
                  {loading ? (
                    <div className="w-5 h-5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>Санал хүсэлт илгээх</span>
                    </>
                  )}
                </button>
              </div>

              <p className="text-[11px] text-center text-slate-400">
                Таны илгээсэн мэдээлэл сургуулийн удирдлагын системд шууд бүртгэгдэнэ.
              </p>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
