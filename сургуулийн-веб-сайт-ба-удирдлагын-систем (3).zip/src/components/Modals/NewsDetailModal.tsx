import React from 'react';
import { useSchool } from '../../context/SchoolContext';
import { X, Calendar, Eye, User, Share2, Tag, Check } from 'lucide-react';

export const NewsDetailModal: React.FC = () => {
  const { selectedNewsModal, setSelectedNewsModal } = useSchool();
  const [copied, setCopied] = React.useState(false);

  if (!selectedNewsModal) return null;

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/65 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
      <div
        className="relative bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-slate-100 flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Image */}
        <div className="relative aspect-16/9 w-full bg-slate-100 shrink-0">
          <img
            src={selectedNewsModal.imageUrl}
            alt={selectedNewsModal.title}
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <button
            onClick={() => setSelectedNewsModal(null)}
            className="absolute top-4 right-4 w-9 h-9 rounded-full bg-black/50 hover:bg-black/70 text-white flex items-center justify-center backdrop-blur-xs transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="absolute bottom-3 left-4 bg-slate-900/90 text-white text-xs font-semibold px-3 py-1 rounded-full shadow-md backdrop-blur-xs">
            {selectedNewsModal.categoryName}
          </div>
        </div>

        {/* Article Body */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6">
          {/* Metadata bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-slate-500 pb-3 border-b border-slate-100">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5 font-medium text-slate-700">
                <Calendar className="w-4 h-4 text-amber-600" />
                {selectedNewsModal.date}
              </span>
              <span className="flex items-center gap-1.5">
                <User className="w-4 h-4 text-slate-400" />
                {selectedNewsModal.author}
              </span>
              <span className="flex items-center gap-1.5">
                <Eye className="w-4 h-4 text-slate-400" />
                {selectedNewsModal.views} үзсэн
              </span>
            </div>

            <button
              onClick={handleShare}
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium transition-colors"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="text-emerald-700 font-semibold">Хууллаа!</span>
                </>
              ) : (
                <>
                  <Share2 className="w-3.5 h-3.5" />
                  <span>Хуваалцах</span>
                </>
              )}
            </button>
          </div>

          {/* Title */}
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 leading-snug">
            {selectedNewsModal.title}
          </h1>

          {/* Excerpt Lead */}
          <div className="p-4 bg-amber-50/60 rounded-2xl border-l-4 border-amber-500 text-xs sm:text-sm text-slate-700 font-medium leading-relaxed">
            {selectedNewsModal.excerpt}
          </div>

          {/* Full Content */}
          <div className="text-sm sm:text-base text-slate-700 leading-relaxed whitespace-pre-line space-y-4">
            {selectedNewsModal.content}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-end shrink-0">
          <button
            onClick={() => setSelectedNewsModal(null)}
            className="text-xs sm:text-sm font-semibold bg-slate-900 hover:bg-slate-800 text-white px-5 py-2.5 rounded-xl transition-colors cursor-pointer"
          >
            Хаах
          </button>
        </div>
      </div>
    </div>
  );
};
