import React from 'react';
import { useSchool } from '../../context/SchoolContext';
import { X, CheckCircle2, Clock, Users, BookOpen, ArrowRight, Tag } from 'lucide-react';

export const ProgramDetailModal: React.FC = () => {
  const { selectedProgramModal, setSelectedProgramModal, setIsAdmissionModalOpen } = useSchool();

  if (!selectedProgramModal) return null;

  const handleApply = () => {
    setSelectedProgramModal(null);
    setIsAdmissionModalOpen(true);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
      <div
        className="relative bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-slate-100 flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Image */}
        <div className="relative aspect-16/9 sm:aspect-21/9 w-full bg-slate-100 shrink-0">
          <img
            src={selectedProgramModal.imageUrl}
            alt={selectedProgramModal.title}
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <button
            onClick={() => setSelectedProgramModal(null)}
            className="absolute top-4 right-4 w-9 h-9 rounded-full bg-black/50 hover:bg-black/70 text-white flex items-center justify-center backdrop-blur-xs transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="absolute bottom-3 left-4 bg-amber-600 text-white text-xs font-bold px-3 py-1 rounded-full shadow-md">
            {selectedProgramModal.categoryName}
          </div>
        </div>

        {/* Scrollable Body */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 leading-tight mb-2">
              {selectedProgramModal.title}
            </h2>
            <p className="text-sm font-medium text-slate-500">
              {selectedProgramModal.subtitle}
            </p>
          </div>

          {/* Tags */}
          <div className="flex flex-wrap gap-2">
            {selectedProgramModal.tags.map((tag, idx) => (
              <span
                key={idx}
                className="inline-flex items-center gap-1 bg-amber-50 text-amber-800 text-xs font-semibold px-2.5 py-1 rounded-lg border border-amber-200/60"
              >
                <Tag className="w-3 h-3 text-amber-600" />
                {tag}
              </span>
            ))}
          </div>

          {/* Quick Meta */}
          <div className="grid grid-cols-2 gap-3 p-4 bg-slate-50 rounded-2xl border border-slate-100 text-xs">
            {selectedProgramModal.ageRange && (
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-amber-600" />
                <div>
                  <span className="text-slate-400 block">Насны ангилал:</span>
                  <span className="font-semibold text-slate-800">
                    {selectedProgramModal.ageRange}
                  </span>
                </div>
              </div>
            )}
            {selectedProgramModal.schedule && (
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-600" />
                <div>
                  <span className="text-slate-400 block">Хуваарь:</span>
                  <span className="font-semibold text-slate-800">
                    {selectedProgramModal.schedule}
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Full Description */}
          <div>
            <h4 className="text-sm font-bold text-slate-900 mb-2 uppercase tracking-wide">
              Хөтөлбөрийн тухай
            </h4>
            <p className="text-sm text-slate-600 leading-relaxed">
              {selectedProgramModal.description}
            </p>
          </div>

          {/* Curriculum */}
          {selectedProgramModal.curriculum && (
            <div>
              <h4 className="text-sm font-bold text-slate-900 mb-2 uppercase tracking-wide">
                Сургалтын төлөвлөгөө & Стандарт
              </h4>
              <div className="p-3 bg-amber-50/50 rounded-xl border border-amber-100 text-xs sm:text-sm text-slate-700 font-medium">
                {selectedProgramModal.curriculum}
              </div>
            </div>
          )}

          {/* Features List */}
          {selectedProgramModal.features && selectedProgramModal.features.length > 0 && (
            <div>
              <h4 className="text-sm font-bold text-slate-900 mb-2 uppercase tracking-wide">
                Онцлох давуу талууд
              </h4>
              <div className="grid grid-cols-1 gap-2.5">
                {selectedProgramModal.features.map((feat, i) => (
                  <div key={i} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-700">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{feat}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer CTA */}
        <div className="p-4 sm:p-6 border-t border-slate-100 bg-slate-50 flex items-center justify-between gap-4 shrink-0">
          <button
            onClick={() => setSelectedProgramModal(null)}
            className="text-xs sm:text-sm font-semibold text-slate-600 hover:text-slate-800 px-4 py-2.5 rounded-xl hover:bg-slate-200 transition-colors"
          >
            Хаах
          </button>
          <button
            onClick={handleApply}
            className="bg-amber-600 hover:bg-amber-700 active:scale-95 text-white text-xs sm:text-sm font-semibold px-6 py-2.5 rounded-xl shadow-md flex items-center gap-2 transition-all cursor-pointer"
          >
            <span>Энэ хөтөлбөрт элсэх хүсэлт өгөх</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
