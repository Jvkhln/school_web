import React from 'react';
import { useSchool } from '../context/SchoolContext';
import { CategoryIcon } from './CategoryIcon';
import { LayoutGrid } from 'lucide-react';

export const CategoryIconBar: React.FC = () => {
  const { categories, activeCategory, setActiveCategory } = useSchool();

  return (
    <section id="categories" className="w-full bg-white border-b border-slate-200/80 py-4 sm:py-6 md:py-8 px-2 sm:px-4 md:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* All Categories Fully Visible on Any Screen (4 columns on mobile, flex wrap on tablet/desktop) */}
        <div className="grid grid-cols-4 md:flex md:flex-wrap md:justify-center gap-1.5 sm:gap-3 md:gap-6 lg:gap-8 items-start justify-items-center">
          {/* "All" Option */}
          <button
            onClick={() => setActiveCategory('all')}
            className={`w-full max-w-[80px] sm:max-w-[95px] md:max-w-[110px] flex flex-col items-center group transition-all p-1 sm:p-1.5 md:p-2 rounded-2xl cursor-pointer text-center ${
              activeCategory === 'all'
                ? 'text-amber-700 font-bold scale-105'
                : 'text-slate-600 hover:text-slate-900 font-medium'
            }`}
          >
            <div
              className={`w-11 h-11 sm:w-13 sm:h-13 md:w-15 md:h-15 lg:w-16 lg:h-16 rounded-full flex items-center justify-center mb-1 sm:mb-1.5 md:mb-2 transition-all cursor-pointer ${
                activeCategory === 'all'
                  ? 'bg-amber-600 text-white shadow-md shadow-amber-600/20 ring-3 sm:ring-4 ring-amber-100'
                  : 'bg-slate-100 text-slate-700 group-hover:bg-slate-200 group-hover:scale-105'
              }`}
            >
              <LayoutGrid className="w-5 h-5 sm:w-5.5 sm:h-5.5 md:w-6 md:h-6 lg:w-7 lg:h-7" />
            </div>
            <span className="text-[10px] sm:text-[11px] md:text-xs lg:text-sm text-center leading-tight tracking-tight cursor-pointer line-clamp-2">
              Бүх чиглэл
            </span>
          </button>

          {/* Dynamic Categories */}
          {categories.map((cat) => {
            const isSelected = activeCategory === cat.slug;
            return (
              <button
                key={cat.id}
                id={`cat-btn-${cat.slug}`}
                onClick={() => setActiveCategory(isSelected ? 'all' : cat.slug)}
                className={`w-full max-w-[80px] sm:max-w-[95px] md:max-w-[110px] flex flex-col items-center group transition-all p-1 sm:p-1.5 md:p-2 rounded-2xl cursor-pointer text-center ${
                  isSelected
                    ? 'text-amber-700 font-bold scale-105'
                    : 'text-slate-600 hover:text-slate-900 font-medium'
                }`}
                title={cat.description}
              >
                <div
                  className={`w-11 h-11 sm:w-13 sm:h-13 md:w-15 md:h-15 lg:w-16 lg:h-16 rounded-full flex items-center justify-center mb-1 sm:mb-1.5 md:mb-2 transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-amber-600 text-white shadow-md shadow-amber-600/20 ring-3 sm:ring-4 ring-amber-100'
                      : 'bg-slate-100 text-slate-700 group-hover:bg-slate-200 group-hover:text-amber-700 group-hover:scale-105'
                  }`}
                >
                  <CategoryIcon name={cat.iconName} className="w-5 h-5 sm:w-5.5 sm:h-5.5 md:w-6 md:h-6 lg:w-7 lg:h-7" />
                </div>
                <span className="text-[10px] sm:text-[11px] md:text-xs lg:text-sm text-center line-clamp-2 leading-tight tracking-tight cursor-pointer">
                  {cat.name}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
};
