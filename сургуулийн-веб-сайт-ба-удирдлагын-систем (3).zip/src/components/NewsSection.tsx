import React, { useState } from 'react';
import { useSchool } from '../context/SchoolContext';
import { Calendar, ArrowRight, Sparkles, PlusCircle, Eye, Tag } from 'lucide-react';

export const NewsSection: React.FC = () => {
  const {
    news,
    setSelectedNewsModal,
    searchQuery,
    categories,
    sectionTexts,
    setIsAdminOpen
  } = useSchool();

  const [selectedNewsCategory, setSelectedNewsCategory] = useState<string>('all');

  // Filter news
  const filteredNews = news.filter((item) => {
    const matchesCategory =
      selectedNewsCategory === 'all' || item.categorySlug === selectedNewsCategory;
    const matchesSearch =
      !searchQuery ||
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.content.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <section id="news" className="py-16 sm:py-20 bg-slate-50 border-t border-slate-200/80 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Section Header Matching the screenshot */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-slate-900 tracking-tight mb-4">
            {sectionTexts.newsTitle}
          </h2>
          <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
            {sectionTexts.newsSubtitle}
          </p>
        </div>

        {/* News Category Filter Pills */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-12">
          <button
            onClick={() => setSelectedNewsCategory('all')}
            className={`px-4 py-1.5 rounded-full text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
              selectedNewsCategory === 'all'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-white text-slate-700 hover:bg-slate-200 border border-slate-200'
            }`}
          >
            Бүх мэдээ ({news.length})
          </button>
          {categories.map((cat) => {
            const count = news.filter((n) => n.categorySlug === cat.slug).length;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedNewsCategory(cat.slug)}
                className={`px-4 py-1.5 rounded-full text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                  selectedNewsCategory === cat.slug
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'bg-white text-slate-700 hover:bg-amber-50 hover:text-amber-700 border border-slate-200'
                }`}
              >
                {cat.name} {count > 0 && <span className="opacity-75 text-xs">({count})</span>}
              </button>
            );
          })}
        </div>

        {/* Empty state */}
        {filteredNews.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-2xl border border-slate-200 max-w-lg mx-auto shadow-xs">
            <Sparkles className="w-10 h-10 text-slate-400 mx-auto mb-3" />
            <h3 className="text-lg font-bold text-slate-800 mb-1">Одоогоор мэдээлэл олдсонгүй</h3>
            <p className="text-sm text-slate-500 mb-4">
              Та админ удирдлагын хэсэг рүү орж энэ ангилалд шинэ мэдээ, нийтлэл оруулах боломжтой.
            </p>
            <button
              onClick={() => setIsAdminOpen(true)}
              className="text-xs bg-amber-600 hover:bg-amber-700 text-white font-semibold px-4 py-2 rounded-lg inline-flex items-center gap-1.5"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>Шинэ мэдээ оруулах</span>
            </button>
          </div>
        ) : (
          /* 3-Column News Grid Matching the Screenshot */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredNews.map((item) => (
              <article
                key={item.id}
                id={`news-card-${item.id}`}
                onClick={() => setSelectedNewsModal(item)}
                className="group cursor-pointer flex flex-col bg-white rounded-2xl overflow-hidden border border-slate-200/80 hover:border-amber-400 hover:shadow-lg transition-all duration-300"
              >
                {/* News Image */}
                <div className="relative aspect-16/10 w-full overflow-hidden bg-slate-100">
                  <img
                    src={item.imageUrl}
                    alt={item.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                    loading="lazy"
                  />
                  {/* Category badge */}
                  <div className="absolute top-3 left-3 bg-slate-900/80 backdrop-blur-xs text-white text-[11px] font-semibold px-2.5 py-1 rounded-md">
                    {item.categoryName}
                  </div>
                </div>

                {/* News Content */}
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    {/* Date Tag matching screenshot style */}
                    <div className="flex items-center gap-2 text-xs text-slate-400 mb-2.5">
                      <span className="inline-flex items-center gap-1 bg-slate-100 text-slate-600 px-2 py-0.5 rounded text-[11px] font-medium">
                        <Calendar className="w-3 h-3 text-slate-400" />
                        <span>{item.date}</span>
                      </span>
                      <span>•</span>
                      <span className="flex items-center gap-1 text-[11px]">
                        <Eye className="w-3 h-3" />
                        <span>{item.views} уншсан</span>
                      </span>
                    </div>

                    {/* News Title */}
                    <h3 className="text-base sm:text-lg font-bold text-slate-900 group-hover:text-amber-600 transition-colors leading-snug line-clamp-2 mb-2">
                      {item.title}
                    </h3>

                    {/* Excerpt */}
                    <p className="text-xs sm:text-sm text-slate-600 leading-relaxed line-clamp-3 mb-4">
                      {item.excerpt}
                    </p>
                  </div>

                  {/* Read More link matching screenshot */}
                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs sm:text-sm font-semibold text-emerald-600 group-hover:text-emerald-700">
                    <span className="flex items-center gap-1 group-hover:underline">
                      Цааш унших
                      <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                    </span>
                    <span className="text-[11px] text-slate-400 font-normal">{item.author}</span>
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}
      </div>
    </section>
  );
};
