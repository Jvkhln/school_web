import React, { useState, useEffect, useCallback } from 'react';
import { useSchool } from '../context/SchoolContext';
import { ChevronLeft, ChevronRight, Sparkles, ArrowRight, MessageSquarePlus } from 'lucide-react';

export const HeroSlider: React.FC = () => {
  const { heroSlides, setIsAdmissionModalOpen } = useSchool();
  const activeSlides = heroSlides.filter((s) => s.active);
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextSlide = useCallback(() => {
    if (activeSlides.length === 0) return;
    setCurrentIndex((prev) => (prev + 1) % activeSlides.length);
  }, [activeSlides.length]);

  const prevSlide = useCallback(() => {
    if (activeSlides.length === 0) return;
    setCurrentIndex((prev) => (prev - 1 + activeSlides.length) % activeSlides.length);
  }, [activeSlides.length]);

  // Auto slide interval
  useEffect(() => {
    if (activeSlides.length <= 1) return;
    const timer = setInterval(() => {
      nextSlide();
    }, 6500);
    return () => clearInterval(timer);
  }, [activeSlides.length, nextSlide]);

  if (activeSlides.length === 0) {
    return null;
  }

  const current = activeSlides[currentIndex];

  const handleCtaClick = () => {
    if (current.buttonLink === '#admission' || current.buttonLink === '#programs') {
      const el = document.getElementById('programs');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    } else if (current.buttonLink.startsWith('#')) {
      const targetId = current.buttonLink.replace('#', '');
      const el = document.getElementById(targetId);
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative w-full h-[520px] sm:h-[600px] lg:h-[650px] overflow-hidden bg-slate-950 select-none">
      {/* Background Images with Cross-fade transition */}
      {activeSlides.map((slide, index) => (
        <div
          key={slide.id}
          className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
            index === currentIndex ? 'opacity-100 scale-100' : 'opacity-0 scale-105 pointer-events-none'
          } transition-transform duration-7000`}
        >
          <img
            src={slide.imageUrl}
            alt={slide.title}
            className="w-full h-full object-cover object-center"
            referrerPolicy="no-referrer"
          />
          {/* Subtle gradient overlay to match reference image */}
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-transparent sm:from-black/75 sm:via-black/40 sm:to-black/20" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/30" />
        </div>
      ))}

      {/* Main Content Container matching layout */}
      <div className="relative max-w-7xl mx-auto h-full px-6 sm:px-10 lg:px-16 flex flex-col justify-center z-10">
        <div className="max-w-2xl text-white space-y-4 sm:space-y-6">
          {/* Top Badge */}
          {current.badge && (
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-600/90 text-white text-xs font-semibold tracking-wider uppercase backdrop-blur-xs border border-emerald-400/30">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{current.badge}</span>
            </div>
          )}

          {/* Main Hero Title */}
          <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-tight drop-shadow-md">
            {current.title}
          </h1>

          {/* Subtitle / Description */}
          <p className="text-base sm:text-lg md:text-xl text-slate-200 font-normal leading-relaxed max-w-xl drop-shadow-sm">
            {current.subtitle}
          </p>

          {/* Action CTA Button - styled like the green pill button in the screenshot */}
          <div className="pt-2 sm:pt-4 flex flex-wrap items-center gap-4">
            <button
              id="hero-cta-button"
              onClick={handleCtaClick}
              className="inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-medium text-sm sm:text-base px-6 py-3 rounded-lg shadow-lg hover:shadow-emerald-600/30 transition-all cursor-pointer"
            >
              <span>{current.buttonText || 'Дэлгэрэнгүй үзэх'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              id="hero-feedback-btn"
              onClick={() => setIsAdmissionModalOpen(true)}
              className="inline-flex items-center gap-2 bg-amber-400 hover:bg-amber-300 active:scale-95 text-slate-950 font-extrabold text-sm sm:text-base px-5 py-3 rounded-lg shadow-lg hover:shadow-amber-400/30 transition-all border border-amber-300 ring-2 ring-amber-400/30 cursor-pointer"
            >
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-slate-950 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-slate-950"></span>
              </span>
              <MessageSquarePlus className="w-4 h-4 text-slate-950 stroke-[2.5]" />
              <span>Санал хүсэлт илгээх</span>
            </button>
          </div>
        </div>
      </div>

      {/* Prev Navigation Arrow Button */}
      {activeSlides.length > 1 && (
        <button
          id="hero-prev-btn"
          onClick={prevSlide}
          className="absolute left-3 sm:left-6 top-1/2 -translate-y-1/2 z-20 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-white/30 hover:bg-white/60 text-white flex items-center justify-center backdrop-blur-xs transition-all active:scale-90 hover:scale-105 cursor-pointer"
          aria-label="Previous slide"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
      )}

      {/* Next Navigation Arrow Button */}
      {activeSlides.length > 1 && (
        <button
          id="hero-next-btn"
          onClick={nextSlide}
          className="absolute right-3 sm:right-6 top-1/2 -translate-y-1/2 z-20 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-white/30 hover:bg-white/60 text-white flex items-center justify-center backdrop-blur-xs transition-all active:scale-90 hover:scale-105 cursor-pointer"
          aria-label="Next slide"
        >
          <ChevronRight className="w-6 h-6" />
        </button>
      )}

      {/* Bottom Horizontal Slider Indicator Dots matching reference */}
      {activeSlides.length > 1 && (
        <div className="absolute bottom-6 left-0 right-0 z-20 flex items-center justify-center gap-2">
          {activeSlides.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentIndex(idx)}
              className={`h-2 transition-all rounded-full cursor-pointer ${
                idx === currentIndex ? 'w-8 bg-emerald-500' : 'w-2 bg-white/50 hover:bg-white/80'
              }`}
              aria-label={`Slide ${idx + 1}`}
            />
          ))}
        </div>
      )}
    </section>
  );
};
