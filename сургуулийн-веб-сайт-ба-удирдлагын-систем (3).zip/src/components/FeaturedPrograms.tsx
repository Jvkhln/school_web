import React from 'react';
import { useSchool } from '../context/SchoolContext';
import { CalendarSidebar } from './CalendarSidebar';
import { ArrowRight, Sparkles, Filter, PlusCircle } from 'lucide-react';

export const FeaturedPrograms: React.FC = () => {
  const {
    programs,
    activeCategory,
    categories,
    sectionTexts,
    setActiveCategory,
    setSelectedProgramModal,
    searchQuery,
    setIsAdminOpen
  } = useSchool();

  // Filter programs based on activeCategory and searchQuery
  const filteredPrograms = programs.filter((prog) => {
    const matchesCategory =
      activeCategory === 'all' || prog.categorySlug === activeCategory;
    const matchesSearch =
      !searchQuery ||
      prog.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      prog.subtitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      prog.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      prog.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  const activeCategoryObj = categories.find((c) => c.slug === activeCategory);

  return (
    <section id="programs" className="py-16 sm:py-20 bg-white px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10 sm:mb-14">
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-slate-900 tracking-tight mb-4">
            {sectionTexts.programsTitle}
          </h2>
          <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
            {sectionTexts.programsSubtitle}
          </p>

          {/* Active Category Filter Tag if active */}
          {activeCategory !== 'all' && (
            <div className="mt-4 inline-flex items-center gap-2 bg-amber-50 text-amber-800 text-sm font-semibold px-4 py-1.5 rounded-full border border-amber-200">
              <Filter className="w-4 h-4 text-amber-600" />
              <span>Ангилал: {activeCategoryObj?.name || activeCategory}</span>
              <button
                onClick={() => setActiveCategory('all')}
                className="text-xs text-amber-600 hover:text-amber-900 ml-1 underline cursor-pointer"
              >
                Бүгдийг харах
              </button>
            </div>
          )}
        </div>

        {/* 2-Column Side-by-side Layout: Programs + Calendar Sidebar */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Main Programs Column (8 of 12 columns on large screens) */}
          <div className="lg:col-span-8">
            {/* Empty state */}
            {filteredPrograms.length === 0 ? (
              <div className="text-center py-16 bg-slate-50 rounded-3xl border border-slate-200 p-8">
                <Sparkles className="w-10 h-10 text-slate-400 mx-auto mb-3" />
                <h3 className="text-lg font-bold text-slate-800 mb-1">
                  Энэ ангилалд одоогоор хөтөлбөр олдсонгүй
                </h3>
                <p className="text-sm text-slate-500 mb-4">
                  Та админ хэсгээс шинэ хөтөлбөр нэмэх эсвэл бүх чиглэлийг харна уу.
                </p>
                <div className="flex justify-center gap-3">
                  <button
                    onClick={() => setActiveCategory('all')}
                    className="text-xs bg-slate-200 hover:bg-slate-300 text-slate-800 font-semibold px-4 py-2 rounded-xl cursor-pointer"
                  >
                    Бүгдийг харуулах
                  </button>
                  <button
                    onClick={() => setIsAdminOpen(true)}
                    className="text-xs bg-amber-600 hover:bg-amber-700 text-white font-semibold px-4 py-2 rounded-xl flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                    <span>Хөтөлбөр нэмэх</span>
                  </button>
                </div>
              </div>
            ) : (
              /* Program Cards Grid (2 columns on tablet/desktop within the 8-col area) */
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 sm:gap-8">
                {filteredPrograms.map((prog) => (
                  <div
                    key={prog.id}
                    id={`program-card-${prog.id}`}
                    onClick={() => setSelectedProgramModal(prog)}
                    className="group cursor-pointer flex flex-col items-center text-center transition-all duration-300 bg-white hover:bg-slate-50/50 p-3 sm:p-4 rounded-3xl border border-transparent hover:border-slate-200/80 hover:shadow-lg"
                  >
                    {/* Image Container */}
                    <div className="relative w-full aspect-16/10 rounded-2xl overflow-hidden mb-4 shadow-2xs group-hover:shadow-md transition-all duration-300 bg-slate-100">
                      <img
                        src={prog.imageUrl}
                        alt={prog.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        referrerPolicy="no-referrer"
                        loading="lazy"
                      />
                      {/* Category pill */}
                      <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-xs text-slate-800 text-xs font-bold px-3 py-1 rounded-full shadow-xs border border-slate-100">
                        {prog.categoryName}
                      </div>
                    </div>

                    {/* Title */}
                    <h3 className="text-base sm:text-lg font-bold text-slate-900 group-hover:text-amber-600 transition-colors leading-snug mb-1.5 px-1">
                      {prog.title}
                    </h3>

                    {/* Subtitle / Description */}
                    <p className="text-xs sm:text-sm text-slate-500 leading-relaxed mb-3 px-1 line-clamp-2">
                      {prog.subtitle}
                    </p>

                    {/* View Details Link */}
                    <div className="mt-auto inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-emerald-600 group-hover:text-emerald-700 group-hover:translate-x-1 transition-all">
                      <span>Дэлгэрэнгүй үзэх</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Calendar Plan Sidebar (4 of 12 columns on large screens) */}
          <div className="lg:col-span-4 w-full">
            <CalendarSidebar />
          </div>
        </div>
      </div>
    </section>
  );
};
