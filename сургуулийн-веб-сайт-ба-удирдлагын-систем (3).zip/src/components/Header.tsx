import React, { useState } from 'react';
import { useSchool } from '../context/SchoolContext';
import {
  School,
  Search,
  Menu,
  X,
  Phone,
  Mail,
  ChevronRight,
  ChevronDown,
  ShieldCheck,
  MessageSquarePlus,
  LogOut,
  BookOpen,
  Calendar,
  Utensils,
  ShieldAlert,
  GraduationCap
} from 'lucide-react';
import { ParentsModal, ParentModalTab } from './Modals/ParentsModal';

export const Header: React.FC = () => {
  const {
    schoolInfo,
    sectionTexts,
    isAdminOpen,
    setIsAdminOpen,
    isAdminAuthenticated,
    openAdmin,
    logoutAdmin,
    setIsAdmissionModalOpen,
    searchQuery,
    setSearchQuery,
    programs
  } = useSchool();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showSearchBox, setShowSearchBox] = useState(false);
  const [parentsDropdownOpen, setParentsDropdownOpen] = useState(false);
  const [parentsModalOpen, setParentsModalOpen] = useState(false);
  const [activeParentTab, setActiveParentTab] = useState<ParentModalTab>('journal');
  const [mobileParentsOpen, setMobileParentsOpen] = useState(false);

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    setParentsDropdownOpen(false);
    if (isAdminOpen) {
      setIsAdminOpen(false);
    }
    setTimeout(() => {
      const element = document.getElementById(id);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };

  const handleAdminClick = () => {
    if (isAdminOpen) {
      setIsAdminOpen(false);
    } else {
      openAdmin();
    }
  };

  const handleFeedbackClick = () => {
    setIsAdmissionModalOpen(true);
  };

  const openParentModalWithTab = (tab: ParentModalTab) => {
    setActiveParentTab(tab);
    setParentsModalOpen(true);
    setParentsDropdownOpen(false);
    setMobileMenuOpen(false);
  };

  return (
    <>
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs transition-all">
        {/* Top micro bar for phone, email, flowing announcement ticker, and admin link */}
        <div className="bg-slate-900 text-slate-200 text-xs py-1.5 px-4 sm:px-8 border-b border-slate-800">
          <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
            {/* Phone & Email contacts */}
            <div className="flex items-center space-x-4 sm:space-x-6 text-slate-300 shrink-0">
              <span className="flex items-center gap-1.5 hover:text-white transition-colors">
                <Phone className="w-3.5 h-3.5 text-amber-400" />
                <span>{schoolInfo.phone}</span>
              </span>
              <span className="hidden sm:flex items-center gap-1.5 hover:text-white transition-colors">
                <Mail className="w-3.5 h-3.5 text-amber-400" />
                <span>{schoolInfo.email}</span>
              </span>
            </div>

            {/* Continuous flowing (marquee) ticker from right to left */}
            <div className="hidden md:flex flex-1 items-center overflow-hidden mx-4 relative">
              <div className="w-full overflow-hidden whitespace-nowrap mask-gradient">
                <div className="animate-marquee inline-block text-amber-300 font-medium tracking-wide">
                  <span className="inline-flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
                    <span>
                      {sectionTexts.topAnnouncement ||
                        'Цахим систем: 2025-2026 Оны сургалт & санал хүсэлт нээлттэй • Кембрижийн олон улсын стандарт & STEM хөтөлбөрийн шинэ элсэлт • Эцэг эхчүүдэд зориулсан цахим журнал, ирц бүртгэл'}
                    </span>
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 sm:gap-3 shrink-0">
              {/* Admin entry in top micro bar */}
              <button
                id="admin-top-toggle-btn"
                onClick={handleAdminClick}
                className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-semibold transition-all cursor-pointer ${
                  isAdminOpen
                    ? 'bg-amber-500 text-slate-950 font-bold shadow-xs ring-2 ring-amber-400/50'
                    : isAdminAuthenticated
                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-700 hover:bg-emerald-900'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-amber-300 border border-slate-700'
                }`}
                title="Админ удирдлагын систем"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                <span>
                  {isAdminOpen
                    ? '← Нүүр хуудас'
                    : isAdminAuthenticated
                    ? 'Админ систем'
                    : 'Админ'}
                </span>
              </button>

              {isAdminAuthenticated && (
                <button
                  id="header-logout-btn"
                  onClick={() => {
                    logoutAdmin();
                  }}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded text-xs font-semibold bg-red-950/80 hover:bg-red-900 text-red-300 border border-red-800/80 transition-all cursor-pointer"
                  title="Админ эрхээс гарах"
                >
                  <LogOut className="w-3 h-3 text-red-400" />
                  <span>Гарах</span>
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Main Navigation Bar */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Logo & School Name */}
            <div
              className="flex items-center gap-3 cursor-pointer group"
              onClick={() => {
                setIsAdminOpen(false);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            >
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-amber-500 via-amber-600 to-amber-700 flex items-center justify-center text-white shadow-md shadow-amber-500/20 group-hover:scale-105 transition-transform overflow-hidden">
                {schoolInfo.logoUrl ? (
                  <img
                    src={schoolInfo.logoUrl}
                    alt={schoolInfo.name}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <School className="w-6 h-6" />
                )}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-lg sm:text-xl tracking-tight text-slate-900 leading-tight">
                    {schoolInfo.name}
                  </span>
                </div>
                <span className="text-xs text-slate-500 font-medium tracking-wide block">
                  Erdmiin Dalai International Academy
                </span>
              </div>
            </div>

            {/* Desktop Navigation Links */}
            <nav className="hidden lg:flex items-center space-x-1 font-medium text-sm text-slate-700">
              <button
                onClick={() => scrollToSection('about')}
                className="px-3 py-2 rounded-lg hover:text-amber-600 hover:bg-amber-50/60 transition-colors cursor-pointer"
              >
                Бидний тухай
              </button>

              {/* Ангилал - Заагч дөхөхөөр урсдаг цэгтэй */}
              <button
                id="nav-categories-btn"
                onClick={() => scrollToSection('categories')}
                className="px-3.5 py-2 rounded-lg hover:text-amber-600 hover:bg-amber-50/60 transition-all cursor-pointer flex items-center gap-2 group relative"
              >
                <span className="relative flex h-2 w-2">
                  <span className="opacity-0 group-hover:opacity-100 group-hover:animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 transition-opacity duration-300"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-slate-300 group-hover:bg-amber-500 group-hover:scale-125 transition-all duration-300"></span>
                </span>
                <span>Ангилал</span>
                <span className="text-[10px] font-bold bg-amber-100/80 text-amber-800 px-1.5 py-0.2 rounded-md group-hover:bg-amber-200 transition-colors">
                  Шинэ
                </span>
              </button>

              {/* Хөтөлбөрүүд - Заагч дөхөхөөр урсдаг цэгтэй */}
              <button
                id="nav-programs-btn"
                onClick={() => scrollToSection('programs')}
                className="px-3.5 py-2 rounded-lg hover:text-amber-600 hover:bg-amber-50/60 transition-all cursor-pointer flex items-center gap-2 group relative"
              >
                <span className="relative flex h-2 w-2">
                  <span className="opacity-0 group-hover:opacity-100 group-hover:animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-500 transition-opacity duration-300"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-slate-300 group-hover:bg-amber-600 group-hover:scale-125 transition-all duration-300"></span>
                </span>
                <span>Хөтөлбөрүүд</span>
                <span className="text-[10px] font-bold bg-slate-100 group-hover:bg-amber-500 group-hover:text-slate-950 text-slate-700 px-1.5 py-0.2 rounded-md transition-colors">
                  {programs.length}
                </span>
              </button>

              <button
                onClick={() => scrollToSection('news')}
                className="px-3 py-2 rounded-lg hover:text-amber-600 hover:bg-amber-50/60 transition-colors cursor-pointer"
              >
                Зар мэдээ
              </button>

              {/* Эцэг эхчүүдэд - Заагч дөхөхөөр доош унадаг цэс (Hover Dropdown) */}
              <div
                className="relative py-2"
                onMouseEnter={() => setParentsDropdownOpen(true)}
                onMouseLeave={() => setParentsDropdownOpen(false)}
              >
                <button
                  id="nav-parents-dropdown-btn"
                  onClick={() => openParentModalWithTab('journal')}
                  className={`px-3.5 py-2 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 font-semibold ${
                    parentsDropdownOpen
                      ? 'text-amber-700 bg-amber-50 shadow-2xs'
                      : 'text-slate-700 hover:text-amber-600 hover:bg-amber-50/60'
                  }`}
                >
                  <span className="relative flex h-2 w-2">
                    <span className="opacity-0 group-hover:opacity-100 group-hover:animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
                  </span>
                  <span>Эцэг эхчүүдэд</span>
                  <ChevronDown
                    className={`w-4 h-4 text-slate-400 transition-transform duration-200 ${
                      parentsDropdownOpen ? 'rotate-180 text-amber-600' : ''
                    }`}
                  />
                </button>

                {/* Dropdown Menu Panel */}
                {parentsDropdownOpen && (
                  <div className="absolute left-0 top-full pt-1.5 w-72 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                    <div className="bg-white rounded-2xl shadow-xl border border-slate-200/90 p-2 space-y-1 ring-1 ring-black/5">
                      <div className="px-3 py-2 border-b border-slate-100 mb-1">
                        <span className="text-[11px] font-bold text-amber-700 uppercase tracking-wider block">
                          Эцэг эхийн цахим үйлчилгээ
                        </span>
                        <span className="text-xs text-slate-500">
                          Сургалт, ирц, дүрэм, хоолны мэдээлэл
                        </span>
                      </div>

                      <button
                        onClick={() => openParentModalWithTab('journal')}
                        className="w-full flex items-start gap-3 p-2.5 rounded-xl hover:bg-amber-50/80 transition-colors text-left group cursor-pointer"
                      >
                        <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center shrink-0 mt-0.5 group-hover:bg-amber-500 group-hover:text-white transition-colors">
                          <BookOpen className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="text-xs font-bold text-slate-900 group-hover:text-amber-800">
                            Цахим журнал & Ирц
                          </div>
                          <div className="text-[11px] text-slate-500 leading-tight">
                            ESIS систем, явцын үнэлгээ, дүн шалгах
                          </div>
                        </div>
                      </button>

                      <button
                        onClick={() => openParentModalWithTab('schedule')}
                        className="w-full flex items-start gap-3 p-2.5 rounded-xl hover:bg-amber-50/80 transition-colors text-left group cursor-pointer"
                      >
                        <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0 mt-0.5 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                          <Calendar className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="text-xs font-bold text-slate-900 group-hover:text-emerald-800">
                            Хичээлийн хуваарь & Календарь
                          </div>
                          <div className="text-[11px] text-slate-500 leading-tight">
                            Ээлжийн цагийн бүтэц, улирлын амралт
                          </div>
                        </div>
                      </button>

                      <button
                        onClick={() => openParentModalWithTab('menu')}
                        className="w-full flex items-start gap-3 p-2.5 rounded-xl hover:bg-amber-50/80 transition-colors text-left group cursor-pointer"
                      >
                        <div className="w-8 h-8 rounded-lg bg-orange-100 text-orange-800 flex items-center justify-center shrink-0 mt-0.5 group-hover:bg-orange-500 group-hover:text-white transition-colors">
                          <Utensils className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="text-xs font-bold text-slate-900 group-hover:text-orange-800">
                            Үдийн цай, хоолны цэс
                          </div>
                          <div className="text-[11px] text-slate-500 leading-tight">
                            7 хоногийн баталгаат шим тэжээлийн цэс
                          </div>
                        </div>
                      </button>

                      <button
                        onClick={() => openParentModalWithTab('rules')}
                        className="w-full flex items-start gap-3 p-2.5 rounded-xl hover:bg-amber-50/80 transition-colors text-left group cursor-pointer"
                      >
                        <div className="w-8 h-8 rounded-lg bg-slate-100 text-slate-800 flex items-center justify-center shrink-0 mt-0.5 group-hover:bg-slate-800 group-hover:text-white transition-colors">
                          <ShieldAlert className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="text-xs font-bold text-slate-900 group-hover:text-slate-950">
                            Сургуулийн дүрэм & Стандарт
                          </div>
                          <div className="text-[11px] text-slate-500 leading-tight">
                            Дүрэмт хувцас, ёс зүйн дотоод журам
                          </div>
                        </div>
                      </button>

                      <div className="pt-1.5 border-t border-slate-100 mt-1">
                        <button
                          onClick={() => {
                            setParentsDropdownOpen(false);
                            handleFeedbackClick();
                          }}
                          className="w-full py-2 px-3 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 text-xs font-bold flex items-center justify-between transition-colors cursor-pointer"
                        >
                          <span>✍️ Санал, хүсэлт илгээх</span>
                          <ChevronRight className="w-3.5 h-3.5 text-amber-700" />
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </nav>

            {/* Right Action buttons */}
            <div className="hidden sm:flex items-center gap-3">
              {/* Search Button */}
              <div className="relative">
                {showSearchBox ? (
                  <div className="flex items-center bg-slate-100 rounded-full px-3 py-1.5 border border-slate-300 w-52 sm:w-64 transition-all">
                    <Search className="w-4 h-4 text-slate-400 mr-2 shrink-0" />
                    <input
                      type="text"
                      placeholder="Мэдээ, хөтөлбөр хайх..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full bg-transparent text-xs text-slate-800 focus:outline-hidden"
                      autoFocus
                    />
                    <button
                      onClick={() => {
                        setSearchQuery('');
                        setShowSearchBox(false);
                      }}
                      className="text-slate-400 hover:text-slate-600 ml-1 cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setShowSearchBox(true)}
                    className="p-2 rounded-full text-slate-600 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer"
                    title="Хайлт хийх"
                  >
                    <Search className="w-5 h-5" />
                  </button>
                )}
              </div>

              {/* Bright Yellow 'Санал хүсэлт' button */}
              <button
                id="header-feedback-btn"
                onClick={handleFeedbackClick}
                className="inline-flex items-center gap-2 bg-amber-400 hover:bg-amber-300 active:scale-95 text-slate-950 font-extrabold text-xs sm:text-sm px-4 py-2.5 rounded-xl shadow-md hover:shadow-amber-400/30 transition-all border border-amber-300 ring-2 ring-amber-400/40 cursor-pointer"
              >
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-slate-950 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-slate-950"></span>
                </span>
                <MessageSquarePlus className="w-4 h-4 text-slate-950 stroke-[2.5]" />
                <span>Санал хүсэлт</span>
              </button>
            </div>

            {/* Mobile menu button */}
            <div className="flex items-center gap-2 lg:hidden">
              <button
                id="mobile-header-feedback-btn"
                onClick={handleFeedbackClick}
                className="sm:hidden text-xs bg-amber-400 hover:bg-amber-300 text-slate-950 font-extrabold px-3 py-1.5 rounded-lg shadow-xs flex items-center gap-1.5 cursor-pointer border border-amber-300"
              >
                <span className="relative flex h-1.5 w-1.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-slate-950 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-slate-950"></span>
                </span>
                <MessageSquarePlus className="w-3.5 h-3.5 stroke-[2.5]" />
                <span>Санал</span>
              </button>

              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 rounded-lg text-slate-700 hover:bg-slate-100 cursor-pointer"
                aria-label="Toggle menu"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile dropdown menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-6 space-y-3 shadow-lg animate-in slide-in-from-top-2">
            {/* Mobile search */}
            <div className="flex items-center bg-slate-100 rounded-xl px-3 py-2 border border-slate-200">
              <Search className="w-4 h-4 text-slate-400 mr-2" />
              <input
                type="text"
                placeholder="Хөтөлбөр, мэдээ хайх..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-transparent text-sm focus:outline-hidden"
              />
              {searchQuery && (
                <button onClick={() => setSearchQuery('')} className="text-slate-400 cursor-pointer">
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 gap-1 text-base font-medium text-slate-800">
              <button
                onClick={() => scrollToSection('about')}
                className="flex items-center justify-between py-2 px-3 rounded-lg hover:bg-amber-50 hover:text-amber-700 cursor-pointer"
              >
                <span>Бидний тухай</span>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>

              {/* Ангилал - Урсдаг цэгтэй (Mobile) */}
              <button
                onClick={() => scrollToSection('categories')}
                className="flex items-center justify-between py-2 px-3 rounded-lg hover:bg-amber-50 hover:text-amber-700 cursor-pointer"
              >
                <div className="flex items-center gap-2">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-80"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
                  </span>
                  <span>Сургалтын ангилал</span>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>

              {/* Хөтөлбөрүүд - Урсдаг цэгтэй (Mobile) */}
              <button
                onClick={() => scrollToSection('programs')}
                className="flex items-center justify-between py-2 px-3 rounded-lg hover:bg-amber-50 hover:text-amber-700 cursor-pointer"
              >
                <div className="flex items-center gap-2">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-500 opacity-80"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-600"></span>
                  </span>
                  <span>Онцлох хөтөлбөрүүд</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-xs bg-amber-400 text-slate-950 font-bold px-1.5 py-0.2 rounded-md">
                    {programs.length}
                  </span>
                  <ChevronRight className="w-4 h-4 text-slate-400" />
                </div>
              </button>

              <button
                onClick={() => scrollToSection('news')}
                className="flex items-center justify-between py-2 px-3 rounded-lg hover:bg-amber-50 hover:text-amber-700 cursor-pointer"
              >
                <span>Сүүлийн үеийн мэдээ</span>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>

              {/* Эцэг эхчүүдэд (Mobile accordion) */}
              <div className="border border-slate-200 rounded-xl overflow-hidden my-1">
                <button
                  onClick={() => setMobileParentsOpen(!mobileParentsOpen)}
                  className="w-full flex items-center justify-between py-2.5 px-3 bg-amber-50/70 text-amber-900 font-bold text-sm cursor-pointer"
                >
                  <div className="flex items-center gap-2">
                    <GraduationCap className="w-4 h-4 text-amber-700" />
                    <span>Эцэг эхчүүдэд зориулсан мэдээлэл</span>
                  </div>
                  <ChevronDown
                    className={`w-4 h-4 text-amber-700 transition-transform ${
                      mobileParentsOpen ? 'rotate-180' : ''
                    }`}
                  />
                </button>

                {mobileParentsOpen && (
                  <div className="p-2 space-y-1 bg-white divide-y divide-slate-100 text-xs">
                    <button
                      onClick={() => openParentModalWithTab('journal')}
                      className="w-full flex items-center justify-between py-2 px-2.5 hover:bg-slate-50 rounded-lg text-slate-700 text-left cursor-pointer"
                    >
                      <span className="flex items-center gap-2">
                        <BookOpen className="w-3.5 h-3.5 text-amber-600" />
                        <span>Цахим журнал & Ирц</span>
                      </span>
                      <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                    </button>

                    <button
                      onClick={() => openParentModalWithTab('schedule')}
                      className="w-full flex items-center justify-between py-2 px-2.5 hover:bg-slate-50 rounded-lg text-slate-700 text-left cursor-pointer"
                    >
                      <span className="flex items-center gap-2">
                        <Calendar className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Хичээлийн хуваарь</span>
                      </span>
                      <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                    </button>

                    <button
                      onClick={() => openParentModalWithTab('menu')}
                      className="w-full flex items-center justify-between py-2 px-2.5 hover:bg-slate-50 rounded-lg text-slate-700 text-left cursor-pointer"
                    >
                      <span className="flex items-center gap-2">
                        <Utensils className="w-3.5 h-3.5 text-orange-600" />
                        <span>Үдийн цай, хоолны цэс</span>
                      </span>
                      <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                    </button>

                    <button
                      onClick={() => openParentModalWithTab('rules')}
                      className="w-full flex items-center justify-between py-2 px-2.5 hover:bg-slate-50 rounded-lg text-slate-700 text-left cursor-pointer"
                    >
                      <span className="flex items-center gap-2">
                        <ShieldAlert className="w-3.5 h-3.5 text-slate-700" />
                        <span>Сургуулийн дүрэм, стандарт</span>
                      </span>
                      <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                    </button>
                  </div>
                )}
              </div>
            </div>

            <div className="pt-3 border-t border-slate-200 flex flex-col gap-2">
              {/* Bright Yellow Feedback in mobile menu */}
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  handleFeedbackClick();
                }}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-amber-400 text-slate-950 text-sm font-extrabold shadow-md hover:bg-amber-300 transition-all cursor-pointer border border-amber-300 ring-2 ring-amber-400/30"
              >
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-slate-950 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-slate-950"></span>
                </span>
                <MessageSquarePlus className="w-4 h-4 text-slate-950 stroke-[2.5]" />
                <span>Санал, хүсэлт илгээх</span>
              </button>

              {/* Admin toggle link in mobile menu */}
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  handleAdminClick();
                }}
                className="w-full flex items-center justify-center gap-2 py-2 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold transition-all cursor-pointer border border-slate-200"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-amber-600" />
                <span>
                  {isAdminOpen
                    ? 'Нүүр хуудас руу шилжих'
                    : isAdminAuthenticated
                    ? 'Админ удирдлагын систем'
                    : 'Админ нэвтрэх'}
                </span>
              </button>

              {isAdminAuthenticated && (
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    logoutAdmin();
                  }}
                  className="w-full flex items-center justify-center gap-2 py-2 px-4 rounded-xl bg-red-50 text-red-700 text-xs font-bold hover:bg-red-100 border border-red-200 cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Админ эрхээс гарах (Logout)</span>
                </button>
              )}
            </div>
          </div>
        )}
      </header>

      {/* Parents Info Modal */}
      <ParentsModal
        isOpen={parentsModalOpen}
        onClose={() => setParentsModalOpen(false)}
        activeTab={activeParentTab}
        onSelectTab={setActiveParentTab}
        onOpenFeedback={handleFeedbackClick}
      />
    </>
  );
};
