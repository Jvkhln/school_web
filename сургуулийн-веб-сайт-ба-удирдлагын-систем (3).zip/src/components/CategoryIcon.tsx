import React from 'react';
import {
  GraduationCap,
  Cpu,
  Globe,
  Award,
  Palette,
  Trophy,
  Trees,
  BookOpen,
  School,
  Sparkles,
  Music,
  Code,
  HeartHandshake,
  Compass,
  Users,
  LucideIcon
} from 'lucide-react';

const ICON_MAP: Record<string, LucideIcon> = {
  GraduationCap,
  Cpu,
  Globe,
  Award,
  Palette,
  Trophy,
  Trees,
  BookOpen,
  School,
  Sparkles,
  Music,
  Code,
  HeartHandshake,
  Compass,
  Users
};

interface CategoryIconProps {
  name: string;
  className?: string;
}

export const CategoryIcon: React.FC<CategoryIconProps> = ({ name, className = 'w-6 h-6' }) => {
  const IconComponent = ICON_MAP[name] || School;
  return <IconComponent className={className} />;
};

export const AVAILABLE_ICON_NAMES = Object.keys(ICON_MAP);
