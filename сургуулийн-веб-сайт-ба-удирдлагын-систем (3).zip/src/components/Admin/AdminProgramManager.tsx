import React, { useState } from 'react';
import { useSchool } from '../../context/SchoolContext';
import { SchoolProgram } from '../../types';
import { ImagePresetPicker } from './ImagePresetPicker';
import {
  Plus,
  Pencil,
  Trash2,
  CheckCircle,
  X,
  GraduationCap,
  Sparkles,
  Tag
} from 'lucide-react';

export const AdminProgramManager: React.FC = () => {
  const { programs, categories, addProgram, updateProgram, deleteProgram } = useSchool();

  const [isEditing, setIsEditing] = useState(false);
  const [currentEditId, setCurrentEditId] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    title: '',
    subtitle: '',
    categorySlug: categories[0]?.slug || 'primary',
    categoryName: categories[0]?.name || 'Бага боловсрол',
    imageUrl: 'https://images.unsplash.com/photo-1509062522246-3755977927d7?q=80&w=900&auto=format&fit=crop',
    tagsString: '1-5-р анги, Суурь мэдлэг, Англи хэл',
    description: '',
    featuresString: 'Стандартын анги танхим\nТуршлагатай багш нар\nНэмэлт дугуйлан',
    curriculum: 'Монгол Улсын ерөнхий боловсролын үндэсний стандарт + Кембриж',
    ageRange: '6 - 18 нас',
    schedule: 'Даваа - Баасан 08:30 - 16:00',
    featured: true,
    order: 1
  });

  const resetForm = () => {
    setFormData({
      title: '',
      subtitle: '',
      categorySlug: categories[0]?.slug || 'primary',
      categoryName: categories[0]?.name || 'Бага боловсрол',
      imageUrl: 'https://images.unsplash.com/photo-1509062522246-3755977927d7?q=80&w=900&auto=format&fit=crop',
      tagsString: '1-5-р анги, Суурь мэдлэг, Англи хэл',
      description: '',
      featuresString: 'Стандартын анги танхим\nТуршлагатай багш нар\nНэмэлт дугуйлан',
      curriculum: 'Монгол Улсын ерөнхий боловсролын үндэсний стандарт + Кембриж',
      ageRange: '6 - 18 нас',
      schedule: 'Даваа - Баасан 08:30 - 16:00',
      featured: true,
      order: 1
    });
    setIsEditing(false);
    setCurrentEditId(null);
  };

  const handleCategoryChange = (slug: string) => {
    const found = categories.find((c) => c.slug === slug);
    setFormData({
      ...formData,
      categorySlug: slug,
      categoryName: found?.name || slug
    });
  };

  const handleEdit = (item: SchoolProgram) => {
    setCurrentEditId(item.id);
    setFormData({
      title: item.title,
      subtitle: item.subtitle,
      categorySlug: item.categorySlug,
      categoryName: item.categoryName,
      imageUrl: item.imageUrl,
      tagsString: item.tags.join(', '),
      description: item.description,
      featuresString: item.features.join('\n'),
      curriculum: item.curriculum || '',
      ageRange: item.ageRange || '',
      schedule: item.schedule || '',
      featured: item.featured ?? true,
      order: item.order
    });
    setIsEditing(true);
    window.scrollTo({ top: 150, behavior: 'smooth' });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title || !formData.description) return;

    const tags = formData.tagsString
      .split(',')
      .map((t) => t.trim())
      .filter(Boolean);

    const features = formData.featuresString
      .split('\n')
      .map((f) => f.trim())
      .filter(Boolean);

    if (currentEditId) {
      updateProgram(currentEditId, {
        title: formData.title,
        subtitle: formData.subtitle,
        categorySlug: formData.categorySlug,
        categoryName: formData.categoryName,
        imageUrl: formData.imageUrl,
        tags,
        description: formData.description,
        features,
        curriculum: formData.curriculum,
        ageRange: formData.ageRange,
        schedule: formData.schedule,
        featured: formData.featured,
        order: formData.order
      });
    } else {
      addProgram({
        title: formData.title,
        subtitle: formData.subtitle,
        categorySlug: formData.categorySlug,
        categoryName: formData.categoryName,
        imageUrl: formData.imageUrl,
        tags,
        description: formData.description,
        features,
        curriculum: formData.curriculum,
        ageRange: formData.ageRange,
        schedule: formData.schedule,
        featured: formData.featured,
        order: formData.order
      });
    }

    resetForm();
  };

  return (
    <div className="space-y-8">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900">
            Сургалтын Хөтөлбөр & Чиглэл Удирдах
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Энд оруулсан хөтөлбөрүүд нүүр хуудасны "Онцлох хөтөлбөрүүд" карт хэсэгт сонгосон ангилалтайгаар гарна.
          </p>
        </div>
        {!isEditing && (
          <button
            onClick={() => {
              resetForm();
              setIsEditing(true);
            }}
            className="bg-amber-600 hover:bg-amber-700 text-white text-xs sm:text-sm font-semibold px-4 py-2.5 rounded-xl shadow-xs flex items-center gap-2 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Шинэ хөтөлбөр нэмэх</span>
          </button>
        )}
      </div>

      {/* Form */}
      {isEditing && (
        <div className="bg-slate-50 rounded-2xl p-6 border border-slate-200 shadow-sm animate-in fade-in">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-200">
            <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
              <GraduationCap className="w-4 h-4 text-amber-600" />
              <span>{currentEditId ? 'Хөтөлбөр засах' : 'Шинэ хөтөлбөр үүсгэх'}</span>
            </h3>
            <button onClick={resetForm} className="text-slate-400 hover:text-slate-600 p-1">
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Title */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Хөтөлбөрийн нэр *
              </label>
              <input
                type="text"
                required
                placeholder="Жишээ: Кембрижийн олон улсын хөтөлбөр"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              />
            </div>

            {/* Subtitle / Bullet Dots text */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Богино тайлбар (Нүүр хуудасны картын нэр доор харагдах цэгтэй жагсаалт)
              </label>
              <input
                type="text"
                placeholder="Жишээ: 1-5-р анги • Check-point • Англи хэл • Сингапур математик"
                value={formData.subtitle}
                onChange={(e) => setFormData({ ...formData, subtitle: e.target.value })}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              />
            </div>

            {/* Category & Order */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Ангилал сонгох *
                </label>
                <select
                  value={formData.categorySlug}
                  onChange={(e) => handleCategoryChange(e.target.value)}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500 font-medium"
                >
                  {categories.map((c) => (
                    <option key={c.id} value={c.slug}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Тагууд (Таслалаар тусгаарлах)
                </label>
                <input
                  type="text"
                  placeholder="Cambridge, IGCSE, Англи хэл"
                  value={formData.tagsString}
                  onChange={(e) => setFormData({ ...formData, tagsString: e.target.value })}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                />
              </div>
            </div>

            {/* Image Selector */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Хөтөлбөрийн ковер зураг
              </label>
              <ImagePresetPicker
                value={formData.imageUrl}
                onChange={(url) => setFormData({ ...formData, imageUrl: url })}
              />
            </div>

            {/* Meta info: Age range, Schedule, Curriculum */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Насны ангилал
                </label>
                <input
                  type="text"
                  placeholder="6-11 нас"
                  value={formData.ageRange}
                  onChange={(e) => setFormData({ ...formData, ageRange: e.target.value })}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Хичээллэх цаг хуваарь
                </label>
                <input
                  type="text"
                  placeholder="08:30 - 15:30"
                  value={formData.schedule}
                  onChange={(e) => setFormData({ ...formData, schedule: e.target.value })}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Сургалтын төлөвлөгөө
                </label>
                <input
                  type="text"
                  placeholder="Cambridge Primary Curriculum"
                  value={formData.curriculum}
                  onChange={(e) => setFormData({ ...formData, curriculum: e.target.value })}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                />
              </div>
            </div>

            {/* Description */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Хөтөлбөрийн дэлгэрэнгүй тайлбар *
              </label>
              <textarea
                rows={3}
                required
                placeholder="Хөтөлбөрийн зорилго, давуу тал, заагдах хичээлүүд..."
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              />
            </div>

            {/* Features (mөp бүрт нэг давуу тал) */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Онцлох давуу талууд (Мөр тус бүрт 1 давуу тал бичнэ үү)
              </label>
              <textarea
                rows={3}
                placeholder="Өдөр өнжүүлэх анги&#10;Үдийн хоол&#10;Усан бассейн"
                value={formData.featuresString}
                onChange={(e) => setFormData({ ...formData, featuresString: e.target.value })}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              />
            </div>

            {/* Buttons */}
            <div className="flex items-center justify-end gap-3 pt-3">
              <button
                type="button"
                onClick={resetForm}
                className="px-4 py-2 text-xs sm:text-sm font-semibold text-slate-600 hover:bg-slate-200 rounded-xl transition-colors"
              >
                Болих
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 text-xs sm:text-sm font-bold bg-amber-600 hover:bg-amber-700 text-white rounded-xl shadow-xs transition-all cursor-pointer"
              >
                {currentEditId ? 'Өөрчлөлтийг хадгалах' : 'Хөтөлбөр үүсгэх'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Program List */}
      <div className="space-y-3">
        <h3 className="text-sm font-bold text-slate-700 uppercase tracking-wider">
          Бүртгэлтэй хөтөлбөрүүд ({programs.length})
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {programs.map((prog) => (
            <div
              key={prog.id}
              className="bg-white p-4 rounded-xl border border-slate-200 flex flex-col justify-between gap-3 hover:border-amber-300 transition-colors shadow-2xs"
            >
              <div className="flex items-start gap-3">
                <img
                  src={prog.imageUrl}
                  alt={prog.title}
                  className="w-20 h-16 object-cover rounded-lg shrink-0"
                  referrerPolicy="no-referrer"
                />
                <div className="min-w-0 flex-1">
                  <span className="text-[11px] font-bold bg-amber-100 text-amber-800 px-2 py-0.5 rounded inline-block mb-1">
                    {prog.categoryName}
                  </span>
                  <h4 className="font-bold text-sm text-slate-900 leading-snug line-clamp-1">
                    {prog.title}
                  </h4>
                  <p className="text-xs text-slate-500 line-clamp-1">{prog.subtitle}</p>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                <span className="text-xs text-slate-400">
                  {prog.tags.slice(0, 2).join(', ')}
                </span>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleEdit(prog)}
                    className="p-1.5 text-slate-600 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors"
                    title="Засах"
                  >
                    <Pencil className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => deleteProgram(prog.id)}
                    className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                    title="Устгах"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
