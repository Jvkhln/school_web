import React, { useState } from 'react';
import { useSchool } from '../../context/SchoolContext';
import { HeroSlide } from '../../types';
import { ImagePresetPicker } from './ImagePresetPicker';
import { Plus, Pencil, Trash2, CheckCircle, X, Image as ImageIcon, Eye, EyeOff } from 'lucide-react';

export const AdminSlideManager: React.FC = () => {
  const { heroSlides, addHeroSlide, updateHeroSlide, deleteHeroSlide } = useSchool();

  const [isEditing, setIsEditing] = useState(false);
  const [currentEditId, setCurrentEditId] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    title: '',
    subtitle: '',
    imageUrl: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?q=80&w=1600&auto=format&fit=crop',
    buttonText: 'Элсэлтийн хүсэлт илгээх',
    buttonLink: '#admission',
    badge: 'ШИНЭ ЭЛСЭЛТ 2025',
    active: true,
    order: 1
  });

  const resetForm = () => {
    setFormData({
      title: '',
      subtitle: '',
      imageUrl: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?q=80&w=1600&auto=format&fit=crop',
      buttonText: 'Элсэлтийн хүсэлт илгээх',
      buttonLink: '#admission',
      badge: 'ШИНЭ ЭЛСЭЛТ 2025',
      active: true,
      order: 1
    });
    setIsEditing(false);
    setCurrentEditId(null);
  };

  const handleEdit = (item: HeroSlide) => {
    setCurrentEditId(item.id);
    setFormData({
      title: item.title,
      subtitle: item.subtitle,
      imageUrl: item.imageUrl,
      buttonText: item.buttonText,
      buttonLink: item.buttonLink,
      badge: item.badge || '',
      active: item.active,
      order: item.order
    });
    setIsEditing(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title) return;

    if (currentEditId) {
      updateHeroSlide(currentEditId, {
        title: formData.title,
        subtitle: formData.subtitle,
        imageUrl: formData.imageUrl,
        buttonText: formData.buttonText,
        buttonLink: formData.buttonLink,
        badge: formData.badge,
        active: formData.active,
        order: formData.order
      });
    } else {
      addHeroSlide({
        title: formData.title,
        subtitle: formData.subtitle,
        imageUrl: formData.imageUrl,
        buttonText: formData.buttonText,
        buttonLink: formData.buttonLink,
        badge: formData.badge,
        active: formData.active,
        order: formData.order
      });
    }

    resetForm();
  };

  return (
    <div className="space-y-8">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900">
            Нүүр хуудасны Слайдер Баннер Удирдах
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Нүүр хуудасны хамгийн дээд хэсэгт байрлах том зургууд, гарчиг болон товчнуудыг тохируулна.
          </p>
        </div>
        {!isEditing && (
          <button
            onClick={() => {
              resetForm();
              setIsEditing(true);
            }}
            className="bg-amber-600 hover:bg-amber-700 text-white text-xs sm:text-sm font-semibold px-4 py-2.5 rounded-xl shadow-xs flex items-center gap-2 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Шинэ баннер нэмэх</span>
          </button>
        )}
      </div>

      {/* Form */}
      {isEditing && (
        <div className="bg-slate-50 rounded-2xl p-6 border border-slate-200 shadow-sm animate-in fade-in">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-200">
            <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
              <ImageIcon className="w-4 h-4 text-amber-600" />
              <span>{currentEditId ? 'Баннер засах' : 'Шинэ баннер нэмэх'}</span>
            </h3>
            <button onClick={resetForm} className="text-slate-400 hover:text-slate-600 p-1">
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Том гарчиг *
              </label>
              <input
                type="text"
                required
                placeholder="Жишээ: 2025-2026 Оны Хичээлийн Жилийн Шинэ Элсэлт Эхэллээ"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Дэд тайлбар өгүүлбэр
              </label>
              <textarea
                rows={2}
                placeholder="Дэлхийн түвшний стандартыг Монгол сэтгэлгээтэй хослуулж..."
                value={formData.subtitle}
                onChange={(e) => setFormData({ ...formData, subtitle: e.target.value })}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Дээд Бадж / Тэмдэглэгээ
                </label>
                <input
                  type="text"
                  placeholder="ШИНЭ ЭЛСЭЛТ 2025"
                  value={formData.badge}
                  onChange={(e) => setFormData({ ...formData, badge: e.target.value })}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Товч дээрх бичиг
                </label>
                <input
                  type="text"
                  placeholder="Элсэлтийн хүсэлт илгээх"
                  value={formData.buttonText}
                  onChange={(e) => setFormData({ ...formData, buttonText: e.target.value })}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Товч дарах линк
                </label>
                <select
                  value={formData.buttonLink}
                  onChange={(e) => setFormData({ ...formData, buttonLink: e.target.value })}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                >
                  <option value="#admission">#admission (Элсэлтийн анкет нээх)</option>
                  <option value="#programs">#programs (Хөтөлбөрүүд рүү гүйлгэх)</option>
                  <option value="#about">#about (Бидний тухай руу гүйлгэх)</option>
                  <option value="#news">#news (Зар мэдээ рүү гүйлгэх)</option>
                </select>
              </div>
            </div>

            {/* Background Image */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Арын дэвсгэр зураг
              </label>
              <ImagePresetPicker
                value={formData.imageUrl}
                onChange={(url) => setFormData({ ...formData, imageUrl: url })}
              />
            </div>

            {/* Active Toggle */}
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="slide-active"
                checked={formData.active}
                onChange={(e) => setFormData({ ...formData, active: e.target.checked })}
                className="rounded text-amber-600 focus:ring-amber-500 w-4 h-4"
              />
              <label htmlFor="slide-active" className="text-xs font-semibold text-slate-700 cursor-pointer">
                Идэвхтэй харуулах
              </label>
            </div>

            {/* Buttons */}
            <div className="flex items-center justify-end gap-3 pt-3">
              <button
                type="button"
                onClick={resetForm}
                className="px-4 py-2 text-xs sm:text-sm font-semibold text-slate-600 hover:bg-slate-200 rounded-xl transition-colors"
              >
                Болих
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 text-xs sm:text-sm font-bold bg-amber-600 hover:bg-amber-700 text-white rounded-xl shadow-xs transition-all cursor-pointer"
              >
                {currentEditId ? 'Өөрчлөлтийг хадгалах' : 'Баннер нэмэх'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* List */}
      <div className="space-y-3">
        <h3 className="text-sm font-bold text-slate-700 uppercase tracking-wider">
          Одоогийн слайдерууд ({heroSlides.length})
        </h3>

        <div className="grid grid-cols-1 gap-3">
          {heroSlides.map((slide) => (
            <div
              key={slide.id}
              className="bg-white p-4 rounded-xl border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-2xs"
            >
              <div className="flex items-center gap-4 min-w-0">
                <img
                  src={slide.imageUrl}
                  alt={slide.title}
                  className="w-24 h-14 object-cover rounded-lg shrink-0"
                  referrerPolicy="no-referrer"
                />
                <div className="min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    {slide.badge && (
                      <span className="text-[10px] font-bold bg-emerald-100 text-emerald-700 px-2 py-0.2 rounded">
                        {slide.badge}
                      </span>
                    )}
                    <span
                      className={`text-[10px] font-semibold px-2 py-0.2 rounded ${
                        slide.active ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-500'
                      }`}
                    >
                      {slide.active ? 'Идэвхтэй' : 'Идэвхгүй'}
                    </span>
                  </div>
                  <h4 className="font-bold text-sm text-slate-900 truncate max-w-md">
                    {slide.title}
                  </h4>
                  <p className="text-xs text-slate-500 truncate max-w-lg">{slide.subtitle}</p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                <button
                  onClick={() => updateHeroSlide(slide.id, { active: !slide.active })}
                  className="p-2 text-slate-500 hover:text-slate-700 rounded-lg hover:bg-slate-100"
                  title={slide.active ? 'Нуух' : 'Идэвхжүүлэх'}
                >
                  {slide.active ? <Eye className="w-4 h-4 text-emerald-600" /> : <EyeOff className="w-4 h-4" />}
                </button>
                <button
                  onClick={() => handleEdit(slide)}
                  className="p-2 text-slate-600 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors"
                  title="Засах"
                >
                  <Pencil className="w-4 h-4" />
                </button>
                <button
                  onClick={() => deleteHeroSlide(slide.id)}
                  className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                  title="Устгах"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
