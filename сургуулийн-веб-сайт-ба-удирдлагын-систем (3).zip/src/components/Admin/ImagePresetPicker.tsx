import React, { useState } from 'react';
import { Image, Check, Upload, Link as LinkIcon } from 'lucide-react';

export const PRESET_SCHOOL_IMAGES = [
  {
    url: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?q=80&w=900&auto=format&fit=crop',
    title: 'Сурагчид, кампус'
  },
  {
    url: 'https://images.unsplash.com/photo-1509062522246-3755977927d7?q=80&w=900&auto=format&fit=crop',
    title: 'Анги танхим, багш'
  },
  {
    url: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?q=80&w=900&auto=format&fit=crop',
    title: 'Робот техник, технологи'
  },
  {
    url: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?q=80&w=900&auto=format&fit=crop',
    title: 'Бага ангийн сурагч'
  },
  {
    url: 'https://images.unsplash.com/photo-1577896851231-70ef18881754?q=80&w=900&auto=format&fit=crop',
    title: 'Лаборатори, туршилт'
  },
  {
    url: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?q=80&w=900&auto=format&fit=crop',
    title: 'Урлаг, хөгжим'
  },
  {
    url: 'https://images.unsplash.com/photo-1521587760476-6c12a4b040da?q=80&w=900&auto=format&fit=crop',
    title: 'Номын сан'
  },
  {
    url: 'https://images.unsplash.com/photo-1544717305-2782549b5136?q=80&w=900&auto=format&fit=crop',
    title: 'Эцэг эхийн өдөрлөг'
  },
  {
    url: 'https://images.unsplash.com/photo-1567427017947-545c5f8d16ad?q=80&w=900&auto=format&fit=crop',
    title: 'Медаль, цом, шагнал'
  }
];

interface ImagePresetPickerProps {
  value: string;
  onChange: (url: string) => void;
}

export const ImagePresetPicker: React.FC<ImagePresetPickerProps> = ({ value, onChange }) => {
  const [customInput, setCustomInput] = useState(value);

  const handleCustomChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCustomInput(e.target.value);
    onChange(e.target.value);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setCustomInput(reader.result);
          onChange(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <LinkIcon className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="url"
            placeholder="Зургийн линк (URL) эсвэл доорх бэлэн зургуудаас сонгох..."
            value={customInput}
            onChange={handleCustomChange}
            className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500"
          />
        </div>
        <label className="cursor-pointer bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors shrink-0">
          <Upload className="w-3.5 h-3.5" />
          <span>Файл хуулах</span>
          <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
        </label>
      </div>

      {/* Preset thumbnails */}
      <div>
        <span className="text-[11px] font-semibold text-slate-500 block mb-1.5">
          Санал болгох зургийн сан:
        </span>
        <div className="grid grid-cols-3 sm:grid-cols-6 md:grid-cols-9 gap-1.5">
          {PRESET_SCHOOL_IMAGES.map((img, i) => {
            const isSelected = value === img.url;
            return (
              <button
                type="button"
                key={i}
                onClick={() => {
                  setCustomInput(img.url);
                  onChange(img.url);
                }}
                className={`relative aspect-square rounded-lg overflow-hidden border-2 transition-all group ${
                  isSelected
                    ? 'border-amber-500 ring-2 ring-amber-400/50 scale-95'
                    : 'border-transparent hover:border-slate-300 opacity-70 hover:opacity-100'
                }`}
                title={img.title}
              >
                <img
                  src={img.url}
                  alt={img.title}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                {isSelected && (
                  <div className="absolute inset-0 bg-amber-600/40 flex items-center justify-center text-white">
                    <Check className="w-4 h-4" />
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Preview */}
      {value && (
        <div className="flex items-center gap-3 p-2 bg-slate-50 rounded-xl border border-slate-200">
          <img
            src={value}
            alt="Preview"
            className="w-16 h-12 object-cover rounded-lg shrink-0"
            referrerPolicy="no-referrer"
          />
          <div className="text-xs text-slate-600 truncate flex-1 font-mono">
            {value.startsWith('data:') ? 'Local Base64 Image' : value}
          </div>
        </div>
      )}
    </div>
  );
};
