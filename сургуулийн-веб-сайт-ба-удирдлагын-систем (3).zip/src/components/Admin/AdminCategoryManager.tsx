import React, { useState } from 'react';
import { useSchool } from '../../context/SchoolContext';
import { CategoryItem } from '../../types';
import { CategoryIcon, AVAILABLE_ICON_NAMES } from '../CategoryIcon';
import { Plus, Pencil, Trash2, X, LayoutGrid } from 'lucide-react';

export const AdminCategoryManager: React.FC = () => {
  const { categories, addCategory, updateCategory, deleteCategory } = useSchool();

  const [isEditing, setIsEditing] = useState(false);
  const [currentEditId, setCurrentEditId] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    nameEn: '',
    slug: '',
    iconName: 'GraduationCap',
    description: ''
  });

  const resetForm = () => {
    setFormData({
      name: '',
      nameEn: '',
      slug: '',
      iconName: 'GraduationCap',
      description: ''
    });
    setIsEditing(false);
    setCurrentEditId(null);
  };

  const handleEdit = (cat: CategoryItem) => {
    setCurrentEditId(cat.id);
    setFormData({
      name: cat.name,
      nameEn: cat.nameEn,
      slug: cat.slug,
      iconName: cat.iconName,
      description: cat.description
    });
    setIsEditing(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name) return;

    const slug =
      formData.slug.trim() ||
      formData.name
        .toLowerCase()
        .replace(/[^\w\s-]/g, '')
        .replace(/\s+/g, '-');

    if (currentEditId) {
      updateCategory(currentEditId, {
        name: formData.name,
        nameEn: formData.nameEn,
        slug: slug,
        iconName: formData.iconName,
        description: formData.description
      });
    } else {
      addCategory({
        name: formData.name,
        nameEn: formData.nameEn,
        slug: slug,
        iconName: formData.iconName,
        description: formData.description
      });
    }

    resetForm();
  };

  return (
    <div className="space-y-8">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900">
            Ангилал Удирдах
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Нүүр хуудасны дээр байрлах дугуй иконтой ангиллын жагсаалт болон мэдээ/хөтөлбөрийн ангиллууд.
          </p>
        </div>
        {!isEditing && (
          <button
            onClick={() => {
              resetForm();
              setIsEditing(true);
            }}
            className="bg-amber-600 hover:bg-amber-700 text-white text-xs sm:text-sm font-semibold px-4 py-2.5 rounded-xl shadow-xs flex items-center gap-2 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Шинэ ангилал нэмэх</span>
          </button>
        )}
      </div>

      {/* Form */}
      {isEditing && (
        <div className="bg-slate-50 rounded-2xl p-6 border border-slate-200 shadow-sm animate-in fade-in">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-200">
            <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
              <LayoutGrid className="w-4 h-4 text-amber-600" />
              <span>{currentEditId ? 'Ангилал засах' : 'Шинэ ангилал үүсгэх'}</span>
            </h3>
            <button onClick={resetForm} className="text-slate-400 hover:text-slate-600 p-1">
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Ангиллын нэр (Монгол) *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Жишээ: Гадаад хэл, Кембриж"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Англи нэр
                </label>
                <input
                  type="text"
                  placeholder="Cambridge & Languages"
                  value={formData.nameEn}
                  onChange={(e) => setFormData({ ...formData, nameEn: e.target.value })}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Слаг (Slug / Түлхүүр үг)
                </label>
                <input
                  type="text"
                  placeholder="cambridge, stem, sports..."
                  value={formData.slug}
                  onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Икон сонгох
                </label>
                <div className="flex items-center gap-2">
                  <div className="w-10 h-10 rounded-xl bg-amber-600 text-white flex items-center justify-center shrink-0">
                    <CategoryIcon name={formData.iconName} className="w-5 h-5" />
                  </div>
                  <select
                    value={formData.iconName}
                    onChange={(e) => setFormData({ ...formData, iconName: e.target.value })}
                    className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                  >
                    {AVAILABLE_ICON_NAMES.map((name) => (
                      <option key={name} value={name}>
                        {name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Товч тайлбар
              </label>
              <textarea
                rows={2}
                placeholder="Ангиллын зорилго, хамрах хүрээ..."
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              />
            </div>

            <div className="flex items-center justify-end gap-3 pt-3">
              <button
                type="button"
                onClick={resetForm}
                className="px-4 py-2 text-xs sm:text-sm font-semibold text-slate-600 hover:bg-slate-200 rounded-xl transition-colors"
              >
                Болих
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 text-xs sm:text-sm font-bold bg-amber-600 hover:bg-amber-700 text-white rounded-xl shadow-xs transition-all cursor-pointer"
              >
                {currentEditId ? 'Өөрчлөлтийг хадгалах' : 'Ангилал үүсгэх'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Grid of Categories */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {categories.map((cat) => (
          <div
            key={cat.id}
            className="bg-white p-5 rounded-2xl border border-slate-200 flex flex-col justify-between gap-4 shadow-2xs hover:border-amber-300 transition-colors"
          >
            <div className="flex items-start gap-3">
              <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-700 border border-amber-200 flex items-center justify-center shrink-0">
                <CategoryIcon name={cat.iconName} className="w-6 h-6" />
              </div>
              <div className="min-w-0">
                <h4 className="font-bold text-base text-slate-900 truncate">{cat.name}</h4>
                <span className="text-xs text-slate-400 font-mono block mb-1">
                  slug: {cat.slug}
                </span>
                <p className="text-xs text-slate-500 line-clamp-2">{cat.description}</p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                onClick={() => handleEdit(cat)}
                className="p-1.5 text-slate-600 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors"
                title="Засах"
              >
                <Pencil className="w-4 h-4" />
              </button>
              <button
                onClick={() => deleteCategory(cat.id)}
                className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                title="Устгах"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
