import React, { useState } from 'react';
import { useSchool } from '../../context/SchoolContext';
import { NewsArticle } from '../../types';
import { ImagePresetPicker } from './ImagePresetPicker';
import {
  Plus,
  Pencil,
  Trash2,
  Calendar,
  Eye,
  CheckCircle,
  X,
  FileText,
  Sparkles,
  Tag
} from 'lucide-react';

export const AdminNewsManager: React.FC = () => {
  const { news, categories, addNewsArticle, updateNewsArticle, deleteNewsArticle } = useSchool();

  const [isEditing, setIsEditing] = useState(false);
  const [currentEditId, setCurrentEditId] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    title: '',
    slug: '',
    categorySlug: categories[0]?.slug || 'primary',
    categoryName: categories[0]?.name || 'Бага боловсрол',
    date: new Date().toLocaleDateString('ja-JP', { year: 'numeric', month: '2-digit', day: '2-digit' }).replace(/-/g, '/'),
    excerpt: '',
    content: '',
    imageUrl: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?q=80&w=900&auto=format&fit=crop',
    author: 'Сургуулийн захиргаа',
    featured: false
  });

  const resetForm = () => {
    setFormData({
      title: '',
      slug: '',
      categorySlug: categories[0]?.slug || 'primary',
      categoryName: categories[0]?.name || 'Бага боловсрол',
      date: new Date().toLocaleDateString('ja-JP', { year: 'numeric', month: '2-digit', day: '2-digit' }).replace(/-/g, '/'),
      excerpt: '',
      content: '',
      imageUrl: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?q=80&w=900&auto=format&fit=crop',
      author: 'Сургуулийн захиргаа',
      featured: false
    });
    setIsEditing(false);
    setCurrentEditId(null);
  };

  const handleCategoryChange = (slug: string) => {
    const found = categories.find((c) => c.slug === slug);
    setFormData({
      ...formData,
      categorySlug: slug,
      categoryName: found?.name || slug
    });
  };

  const handleEdit = (item: NewsArticle) => {
    setCurrentEditId(item.id);
    setFormData({
      title: item.title,
      slug: item.slug,
      categorySlug: item.categorySlug,
      categoryName: item.categoryName,
      date: item.date,
      excerpt: item.excerpt,
      content: item.content,
      imageUrl: item.imageUrl,
      author: item.author,
      featured: item.featured
    });
    setIsEditing(true);
    window.scrollTo({ top: 150, behavior: 'smooth' });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title || !formData.content) return;

    if (currentEditId) {
      updateNewsArticle(currentEditId, {
        title: formData.title,
        slug: formData.slug || formData.title.toLowerCase().replace(/\s+/g, '-'),
        categorySlug: formData.categorySlug,
        categoryName: formData.categoryName,
        date: formData.date,
        excerpt: formData.excerpt,
        content: formData.content,
        imageUrl: formData.imageUrl,
        author: formData.author,
        featured: formData.featured
      });
    } else {
      addNewsArticle({
        title: formData.title,
        slug: formData.slug || formData.title.toLowerCase().replace(/\s+/g, '-'),
        categorySlug: formData.categorySlug,
        categoryName: formData.categoryName,
        date: formData.date,
        excerpt: formData.excerpt || formData.content.slice(0, 140) + '...',
        content: formData.content,
        imageUrl: formData.imageUrl,
        author: formData.author,
        featured: formData.featured
      });
    }

    resetForm();
  };

  return (
    <div className="space-y-8">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900">
            Мэдээ, Нийтлэл Удирдах
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Энд оруулсан мэдээ нүүр хуудасны "Сүүлийн үеийн мэдээ" хэсэгт сонгосон ангиллаараа автоматаар нийтлэгдэнэ.
          </p>
        </div>
        {!isEditing && (
          <button
            onClick={() => {
              resetForm();
              setIsEditing(true);
            }}
            className="bg-amber-600 hover:bg-amber-700 text-white text-xs sm:text-sm font-semibold px-4 py-2.5 rounded-xl shadow-xs flex items-center gap-2 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Шинэ мэдээ нийтлэх</span>
          </button>
        )}
      </div>

      {/* Edit / Create Form */}
      {isEditing && (
        <div className="bg-slate-50 rounded-2xl p-6 border border-slate-200 shadow-sm animate-in fade-in">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-200">
            <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
              <FileText className="w-4 h-4 text-amber-600" />
              <span>{currentEditId ? 'Мэдээ засах' : 'Шинэ мэдээ оруулах'}</span>
            </h3>
            <button onClick={resetForm} className="text-slate-400 hover:text-slate-600 p-1">
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Title */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Мэдээний гарчиг *
              </label>
              <input
                type="text"
                required
                placeholder="Жишээ: 12-р ангийн төгсөгчид олон улсын тэтгэлэг хүртлээ"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              />
            </div>

            {/* Category & Date & Author */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Ангилал сонгох *
                </label>
                <select
                  value={formData.categorySlug}
                  onChange={(e) => handleCategoryChange(e.target.value)}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500 font-medium"
                >
                  {categories.map((c) => (
                    <option key={c.id} value={c.slug}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Огноо
                </label>
                <input
                  type="text"
                  placeholder="2025/02/20"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Нийтэлсэн зохиогч
                </label>
                <input
                  type="text"
                  value={formData.author}
                  onChange={(e) => setFormData({ ...formData, author: e.target.value })}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                />
              </div>
            </div>

            {/* Image Selector */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Зураг сонгох / холбох
              </label>
              <ImagePresetPicker
                value={formData.imageUrl}
                onChange={(url) => setFormData({ ...formData, imageUrl: url })}
              />
            </div>

            {/* Excerpt */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Товч хураангуй (Нүүр хуудасны картан дээр харагдана)
              </label>
              <textarea
                rows={2}
                placeholder="Мэдээний товч хураангуй 1-2 өгүүлбэр..."
                value={formData.excerpt}
                onChange={(e) => setFormData({ ...formData, excerpt: e.target.value })}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              />
            </div>

            {/* Content */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Дэлгэрэнгүй агуулга *
              </label>
              <textarea
                rows={6}
                required
                placeholder="Мэдээний бүрэн эх бичвэрийг энд бичнэ үү..."
                value={formData.content}
                onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              />
            </div>

            {/* Featured toggle */}
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="featured-check"
                checked={formData.featured}
                onChange={(e) => setFormData({ ...formData, featured: e.target.checked })}
                className="rounded text-amber-600 focus:ring-amber-500 w-4 h-4"
              />
              <label htmlFor="featured-check" className="text-xs font-semibold text-slate-700 cursor-pointer">
                Онцлох мэдээ болгон тэмдэглэх
              </label>
            </div>

            {/* Buttons */}
            <div className="flex items-center justify-end gap-3 pt-3">
              <button
                type="button"
                onClick={resetForm}
                className="px-4 py-2 text-xs sm:text-sm font-semibold text-slate-600 hover:bg-slate-200 rounded-xl transition-colors"
              >
                Болих
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 text-xs sm:text-sm font-bold bg-amber-600 hover:bg-amber-700 text-white rounded-xl shadow-xs transition-all cursor-pointer"
              >
                {currentEditId ? 'Өөрчлөлтийг хадгалах' : 'Нийтлэх'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* List of News Items */}
      <div className="space-y-3">
        <h3 className="text-sm font-bold text-slate-700 uppercase tracking-wider">
          Нийтлэгдсэн мэдээллүүд ({news.length})
        </h3>

        <div className="grid grid-cols-1 gap-3">
          {news.map((item) => (
            <div
              key={item.id}
              className="bg-white p-4 rounded-xl border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 hover:border-amber-300 transition-colors shadow-2xs"
            >
              <div className="flex items-center gap-4 min-w-0">
                <img
                  src={item.imageUrl}
                  alt={item.title}
                  className="w-16 h-12 object-cover rounded-lg shrink-0"
                  referrerPolicy="no-referrer"
                />
                <div className="min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[11px] font-bold bg-amber-100 text-amber-800 px-2 py-0.5 rounded">
                      {item.categoryName}
                    </span>
                    <span className="text-xs text-slate-400">{item.date}</span>
                    {item.featured && (
                      <span className="text-[10px] bg-emerald-100 text-emerald-700 font-semibold px-1.5 py-0.2 rounded">
                        Онцлох
                      </span>
                    )}
                  </div>
                  <h4 className="font-bold text-sm text-slate-900 truncate max-w-md">
                    {item.title}
                  </h4>
                  <p className="text-xs text-slate-500 truncate max-w-lg">{item.excerpt}</p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                <button
                  onClick={() => handleEdit(item)}
                  className="p-2 text-slate-600 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors"
                  title="Засах"
                >
                  <Pencil className="w-4 h-4" />
                </button>
                <button
                  onClick={() => deleteNewsArticle(item.id)}
                  className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                  title="Устгах"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
