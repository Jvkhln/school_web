import React, { useState } from 'react';
import { useSchool } from '../../context/SchoolContext';
import { SchoolInfo } from '../../types';
import { db } from '../../lib/firebase';
import { doc, setDoc } from 'firebase/firestore';
import {
  Save,
  RotateCcw,
  Download,
  Upload,
  CheckCircle2,
  AlertCircle,
  Building,
  Phone,
  Mail,
  MapPin,
  Clock,
  KeyRound,
  ShieldCheck,
  User,
  Sparkles,
  Database,
  CloudUpload,
  Loader2
} from 'lucide-react';

export const AdminSettingsManager: React.FC = () => {
  const {
    schoolInfo,
    updateSchoolInfo,
    resetToDefaults,
    exportDataJson,
    importDataJson,
    adminUsername,
    updateAdminCredentials,
    news,
    programs,
    categories,
    heroSlides,
    calendarEvents,
    sectionTexts
  } = useSchool();

  const [formData, setFormData] = useState<SchoolInfo>(schoolInfo);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [importError, setImportError] = useState<string | null>(null);
  const [backupMsg, setBackupMsg] = useState<string | null>(null);

  // Cloud sync state
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStatus, setSyncStatus] = useState<string | null>(null);

  // Password & credentials state
  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [newUsername, setNewUsername] = useState(adminUsername);
  const [credMsg, setCredMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateSchoolInfo(formData);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const handleSyncToFirebase = async () => {
    setIsSyncing(true);
    setSyncStatus(null);
    try {
      // 1. Settings
      await setDoc(doc(db, 'settings', 'schoolInfo'), schoolInfo);
      await setDoc(doc(db, 'settings', 'sectionTexts'), sectionTexts);

      // 2. Programs
      for (const prog of programs) {
        await setDoc(doc(db, 'programs', prog.id), prog);
      }

      // 3. News
      for (const item of news) {
        await setDoc(doc(db, 'news', item.id), item);
      }

      // 4. Categories
      for (const cat of categories) {
        await setDoc(doc(db, 'categories', cat.id), cat);
      }

      // 5. Slides
      for (const slide of heroSlides) {
        await setDoc(doc(db, 'slides', slide.id), slide);
      }

      // 6. Calendar
      for (const event of calendarEvents) {
        await setDoc(doc(db, 'calendar', event.id), event);
      }

      setSyncStatus('Бүх өгөгдөл Firebase Firestore бааз руу амжилттай синк хийгдэж хадгалагдлаа!');
      setTimeout(() => setSyncStatus(null), 5000);
    } catch (err) {
      console.error('Firebase sync error:', err);
      setSyncStatus('Өгөгдөл синк хийхэд алдаа гарлаа. Интернэт холболтоо шалгана уу.');
    } finally {
      setIsSyncing(false);
    }
  };

  const handlePasswordChange = (e: React.FormEvent) => {
    e.preventDefault();
    setCredMsg(null);
    const res = updateAdminCredentials(currentPass, newPass, newUsername);
    if (res.success) {
      setCredMsg({ type: 'success', text: res.message });
      setCurrentPass('');
      setNewPass('');
    } else {
      setCredMsg({ type: 'error', text: res.message });
    }
  };

  const handleExport = () => {
    const dataStr = exportDataJson();
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `school_backup_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        if (text) {
          const success = importDataJson(text);
          if (success) {
            setBackupMsg('Мэдээллийг амжилттай сэргээж орууллаа!');
            setImportError(null);
            setTimeout(() => setBackupMsg(null), 4000);
          } else {
            setImportError('JSON файл уншихад алдаа гарлаа. Формат зөв эсэхийг шалгана уу.');
          }
        }
      };
      reader.readAsText(file);
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900">
            Сургуулийн Үндсэн Тохиргоо & Өгөгдөл
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Сургуулийн нэр, утас, имэйл, хаяг, тоон үзүүлэлтүүд болон админы нууц үгийг солих.
          </p>
        </div>

        {saveSuccess && (
          <div className="inline-flex items-center gap-1.5 bg-emerald-100 text-emerald-800 text-xs font-bold px-3 py-1.5 rounded-xl animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Амжилттай хадгалагдлаа!</span>
          </div>
        )}
      </div>

      {/* Main Settings Form */}
      <form onSubmit={handleSave} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-6">
        <h3 className="font-bold text-base text-slate-900 flex items-center gap-2 border-b border-slate-100 pb-2">
          <Building className="w-4 h-4 text-amber-600" />
          <span>Ерөнхий танилцуулга & Холбоо барих</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Сургуулийн албан ёсны нэр *
            </label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Сургуулийн лого зураг (Зургийн линк эсвэл хоосон үлдээвэл үндсэн тэмдэг гарна)
            </label>
            <div className="flex items-center gap-2">
              <input
                type="url"
                placeholder="https://... логоны зургийн хаяг"
                value={formData.logoUrl || ''}
                onChange={(e) => setFormData({ ...formData, logoUrl: e.target.value })}
                className="flex-1 px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              />
              {formData.logoUrl && (
                <div className="w-9 h-9 rounded-lg border border-slate-200 overflow-hidden bg-slate-100 flex items-center justify-center shrink-0">
                  <img src={formData.logoUrl} alt="Logo" className="w-full h-full object-contain" />
                </div>
              )}
            </div>
            <p className="text-[11px] text-slate-500 mt-1">
              Жишээ: Шинэ логоныхоо зургийн линкийг оруулж хадгалснаар толгой болон хөл хэсгийн бүх лого солигдоно.
            </p>
          </div>

          <div className="sm:col-span-2">
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Уриа үг (Motto)
            </label>
            <input
              type="text"
              value={formData.motto}
              onChange={(e) => setFormData({ ...formData, motto: e.target.value })}
              className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Сургуулийн товч танилцуулга
          </label>
          <textarea
            rows={2}
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Утасны дугаар
            </label>
            <input
              type="text"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Имэйл хаяг
            </label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Ажиллах цагийн хуваарь
            </label>
            <input
              type="text"
              value={formData.workingHours}
              onChange={(e) => setFormData({ ...formData, workingHours: e.target.value })}
              className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Сургуулийн хаяг байршил
          </label>
          <input
            type="text"
            value={formData.address}
            onChange={(e) => setFormData({ ...formData, address: e.target.value })}
            className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500"
          />
        </div>

        {/* Numbers & Stats */}
        <h3 className="font-bold text-base text-slate-900 flex items-center gap-2 border-b border-slate-100 pb-2 pt-2">
          <Sparkles className="w-4 h-4 text-amber-600" />
          <span>Тоон үзүүлэлтүүд (Stats Counter)</span>
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Нийт сурагч
            </label>
            <input
              type="number"
              value={formData.studentsCount}
              onChange={(e) =>
                setFormData({ ...formData, studentsCount: Number(e.target.value) })
              }
              className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Нийт багш
            </label>
            <input
              type="number"
              value={formData.teachersCount}
              onChange={(e) =>
                setFormData({ ...formData, teachersCount: Number(e.target.value) })
              }
              className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Их сургуулийн элсэлт %
            </label>
            <input
              type="number"
              value={formData.collegeAcceptanceRate}
              onChange={(e) =>
                setFormData({ ...formData, collegeAcceptanceRate: Number(e.target.value) })
              }
              className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Клуб, дугуйлан
            </label>
            <input
              type="number"
              value={formData.clubsCount}
              onChange={(e) =>
                setFormData({ ...formData, clubsCount: Number(e.target.value) })
              }
              className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500"
            />
          </div>
        </div>

        <div className="pt-2 flex justify-end">
          <button
            type="submit"
            className="bg-amber-600 hover:bg-amber-700 active:scale-95 text-white font-bold text-xs sm:text-sm px-6 py-2.5 rounded-xl shadow-xs transition-all flex items-center gap-2 cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>Тохиргоог хадгалах</span>
          </button>
        </div>
      </form>

      {/* Admin Security & Password Change Form */}
      <form
        onSubmit={handlePasswordChange}
        className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-5"
      >
        <div className="flex items-center justify-between border-b border-slate-100 pb-2">
          <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-amber-600" />
            <span>Админы Нэвтрэх Нэр & Нууц Үг Солих</span>
          </h3>
          <span className="text-[11px] text-slate-400">
            Одоогийн хэрэглэгч: <strong className="text-slate-700">{adminUsername}</strong>
          </span>
        </div>

        {credMsg && (
          <div
            className={`p-3 rounded-xl text-xs flex items-center gap-2 animate-in fade-in ${
              credMsg.type === 'success'
                ? 'bg-emerald-50 border border-emerald-200 text-emerald-800'
                : 'bg-red-50 border border-red-200 text-red-700'
            }`}
          >
            {credMsg.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
            ) : (
              <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
            )}
            <span>{credMsg.text}</span>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Нэвтрэх нэр (Username)
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <User className="w-3.5 h-3.5" />
              </div>
              <input
                type="text"
                required
                value={newUsername}
                onChange={(e) => setNewUsername(e.target.value)}
                placeholder="Жишээ: admin"
                className="w-full pl-8 pr-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Одоогийн нууц үг *
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <KeyRound className="w-3.5 h-3.5" />
              </div>
              <input
                type="password"
                required
                value={currentPass}
                onChange={(e) => setCurrentPass(e.target.value)}
                placeholder="Анхдагч: admin123"
                className="w-full pl-8 pr-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Шинэ нууц үг *
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <KeyRound className="w-3.5 h-3.5 text-amber-500" />
              </div>
              <input
                type="password"
                required
                minLength={4}
                value={newPass}
                onChange={(e) => setNewPass(e.target.value)}
                placeholder="Шинэ нууц үг (дор хаяж 4 үсэг)"
                className="w-full pl-8 pr-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between pt-1">
          <p className="text-[11px] text-slate-400">
            Нууц үгээ сольсны дараа дараагийн нэвтрэлтэд шинэ нууц үгээ ашиглана.
          </p>
          <button
            type="submit"
            className="bg-slate-900 hover:bg-slate-800 active:scale-95 text-white font-bold text-xs sm:text-sm px-5 py-2 rounded-xl shadow-xs transition-all flex items-center gap-2 cursor-pointer"
          >
            <KeyRound className="w-4 h-4 text-amber-400" />
            <span>Нууц үг солих</span>
          </button>
        </div>
      </form>

      {/* Firebase Cloud Firestore Sync Card */}
      <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white p-6 rounded-2xl border border-slate-700 shadow-md space-y-4">
        <div className="flex items-center justify-between border-b border-slate-700/80 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
              <Database className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <span>Google Firebase Firestore бааз</span>
                <span className="bg-emerald-500/20 text-emerald-300 text-[10px] font-semibold px-2 py-0.5 rounded-full border border-emerald-500/30">
                  Холбогдсон
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">
                Сургуулийн бүх мэдээ, хөтөлбөр, хуанли үүлэн бааз (Cloud Database) дээр найдвартай хадгалагдана.
              </p>
            </div>
          </div>
        </div>

        {syncStatus && (
          <div className="p-3 bg-emerald-950/80 border border-emerald-600/50 text-emerald-200 text-xs rounded-xl flex items-center gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{syncStatus}</span>
          </div>
        )}

        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          <p className="text-xs text-slate-300 max-w-md">
            Админ самбарт өөрчлөлт хийхэд автоматаар хадгалагддаг. Мөн одоогийн бүх анхны мэдээллийг Firebase бааз руу нэг дор синк хийж болно.
          </p>
          <button
            type="button"
            disabled={isSyncing}
            onClick={handleSyncToFirebase}
            className="bg-amber-500 hover:bg-amber-400 active:scale-95 disabled:opacity-50 text-slate-950 font-bold text-xs px-4 py-2.5 rounded-xl shadow-xs transition-all flex items-center gap-2 cursor-pointer"
          >
            {isSyncing ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Синк хийж байна...</span>
              </>
            ) : (
              <>
                <CloudUpload className="w-4 h-4" />
                <span>Бүх өгөгдлийг Firebase руу синк хийх</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Backup, Export & Reset Section */}
      <div className="bg-slate-100 p-6 rounded-2xl border border-slate-200 space-y-4">
        <h3 className="font-bold text-sm text-slate-800 uppercase tracking-wider">
          Өгөгдлийн сан ба Нөөц хуулбар
        </h3>
        <p className="text-xs text-slate-600">
          Сайтын бүх мэдээ, хөтөлбөр, слайдер, ангиллын тохиргоог файл болгон татаж авах эсвэл өмнөх өгөгдлийг сэргээх боломжтой.
        </p>

        {backupMsg && (
          <div className="p-3 bg-emerald-100 border border-emerald-200 text-emerald-800 text-xs font-semibold rounded-xl flex items-center gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{backupMsg}</span>
          </div>
        )}

        {importError && (
          <div className="p-3 bg-red-100 border border-red-200 text-red-700 text-xs rounded-xl flex items-center gap-2 animate-in fade-in">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{importError}</span>
          </div>
        )}

        <div className="flex flex-wrap gap-3 pt-2">
          <button
            type="button"
            onClick={handleExport}
            className="bg-white hover:bg-slate-50 text-slate-800 text-xs font-semibold px-4 py-2.5 rounded-xl border border-slate-300 shadow-2xs flex items-center gap-2 transition-all cursor-pointer"
          >
            <Download className="w-4 h-4 text-amber-600" />
            <span>Бүх өгөгдлийг JSON татах (Backup)</span>
          </button>

          <label className="bg-white hover:bg-slate-50 text-slate-800 text-xs font-semibold px-4 py-2.5 rounded-xl border border-slate-300 shadow-2xs flex items-center gap-2 transition-all cursor-pointer">
            <Upload className="w-4 h-4 text-amber-600" />
            <span>JSON файлаас сэргээх (Restore)</span>
            <input type="file" accept=".json" onChange={handleImport} className="hidden" />
          </label>

          <button
            type="button"
            onClick={() => {
              resetToDefaults();
              setBackupMsg('Өгөгдлийг анхны хэлбэрт амжилттай буцаалаа.');
              setTimeout(() => setBackupMsg(null), 4000);
            }}
            className="text-xs font-semibold text-slate-500 hover:text-red-600 px-4 py-2.5 rounded-xl hover:bg-red-50 transition-all flex items-center gap-2 ml-auto cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Анхны өгөгдөл рүү буцаах</span>
          </button>
        </div>
      </div>
    </div>
  );
};
