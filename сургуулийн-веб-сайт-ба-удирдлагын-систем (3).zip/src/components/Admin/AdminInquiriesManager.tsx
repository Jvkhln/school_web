import React, { useState } from 'react';
import { useSchool } from '../../context/SchoolContext';
import {
  Mail,
  Phone,
  Calendar,
  User,
  CheckCircle2,
  Clock,
  Trash2,
  MessageSquare,
  HelpCircle,
  AlertTriangle,
  GraduationCap,
  Filter,
  Sparkles
} from 'lucide-react';
import { AdmissionInquiry } from '../../types';

export const AdminInquiriesManager: React.FC = () => {
  const { inquiries, updateInquiryStatus, deleteInquiry } = useSchool();
  const [filterType, setFilterType] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const filteredInquiries = inquiries.filter((inq) => {
    if (filterType !== 'all' && (inq.type || 'admission') !== filterType) return false;
    if (filterStatus !== 'all' && inq.status !== filterStatus) return false;
    return true;
  });

  const getTypeBadge = (type?: string) => {
    switch (type) {
      case 'feedback':
        return (
          <span className="bg-amber-100 text-amber-900 border border-amber-300 text-xs font-extrabold px-2.5 py-0.5 rounded-full flex items-center gap-1">
            <MessageSquare className="w-3 h-3 text-amber-700" />
            <span>Санал хүсэлт</span>
          </span>
        );
      case 'question':
        return (
          <span className="bg-sky-100 text-sky-800 border border-sky-200 text-xs font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1">
            <HelpCircle className="w-3 h-3 text-sky-600" />
            <span>Асуулт</span>
          </span>
        );
      case 'complaint':
        return (
          <span className="bg-rose-100 text-rose-800 border border-rose-200 text-xs font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1">
            <AlertTriangle className="w-3 h-3 text-rose-600" />
            <span>Шүүмж</span>
          </span>
        );
      case 'admission':
      default:
        return (
          <span className="bg-indigo-100 text-indigo-800 border border-indigo-200 text-xs font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1">
            <GraduationCap className="w-3 h-3 text-indigo-600" />
            <span>Элсэлт</span>
          </span>
        );
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'new':
        return (
          <span className="bg-amber-100 text-amber-800 text-xs font-bold px-2.5 py-1 rounded-full flex items-center gap-1">
            <Clock className="w-3 h-3" />
            <span>Шинэ</span>
          </span>
        );
      case 'contacted':
        return (
          <span className="bg-blue-100 text-blue-800 text-xs font-bold px-2.5 py-1 rounded-full flex items-center gap-1">
            <Phone className="w-3 h-3" />
            <span>Холбогдсон</span>
          </span>
        );
      case 'approved':
        return (
          <span className="bg-emerald-100 text-emerald-800 text-xs font-bold px-2.5 py-1 rounded-full flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" />
            <span>Шийдвэрлэсэн</span>
          </span>
        );
      case 'rejected':
        return (
          <span className="bg-rose-100 text-rose-700 text-xs font-bold px-2.5 py-1 rounded-full">
            Татгалзсан
          </span>
        );
      default:
        return (
          <span className="bg-slate-100 text-slate-700 text-xs font-bold px-2.5 py-1 rounded-full">
            {status}
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 flex items-center gap-2">
            <span>Ирсэн Санал, Хүсэлтүүд</span>
            <span className="text-sm bg-amber-400 text-slate-950 font-bold px-2.5 py-0.5 rounded-full shadow-2xs">
              {inquiries.length}
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Вэб сайтын "Санал хүсэлт" цонхоор хэрэглэгч, эцэг эх, сурагчдын илгээсэн бүх мэдээллүүд.
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs">
            <Filter className="w-3.5 h-3.5 text-slate-500 ml-1" />
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="bg-transparent border-0 font-bold text-slate-700 focus:outline-hidden cursor-pointer"
            >
              <option value="all">Бүх төрөл</option>
              <option value="feedback">Санал хүсэлт</option>
              <option value="question">Асуулт</option>
              <option value="admission">Элсэлт</option>
              <option value="complaint">Шүүмж</option>
            </select>
          </div>

          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs">
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="bg-transparent border-0 font-bold text-slate-700 focus:outline-hidden cursor-pointer"
            >
              <option value="all">Бүх төлөв</option>
              <option value="new">Шинэ</option>
              <option value="contacted">Холбогдсон</option>
              <option value="approved">Шийдвэрлэсэн</option>
              <option value="rejected">Татгалзсан</option>
            </select>
          </div>
        </div>
      </div>

      {filteredInquiries.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl border border-slate-200 shadow-2xs">
          <Mail className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-700">Одоогоор хүсэлт ирээгүй байна</h3>
          <p className="text-xs text-slate-400 mt-1">Шинэ санал хүсэлт ирэх үед энд харагдана.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {filteredInquiries.map((inq) => {
            const senderName = inq.name || inq.studentName || inq.parentName || 'Хэрэглэгч';
            const messageBody = inq.message || inq.notes || '';

            return (
              <div
                key={inq.id}
                className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs hover:border-amber-300 transition-colors space-y-4"
              >
                <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center font-bold shadow-2xs">
                      <User className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold text-base text-slate-900">{senderName}</h3>
                        {getTypeBadge(inq.type)}
                      </div>
                      {inq.subject && (
                        <span className="text-xs text-amber-800 font-semibold block mt-0.5">
                          Сэдэв: {inq.subject}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    {getStatusBadge(inq.status)}
                    <span className="text-xs text-slate-400 flex items-center gap-1 font-medium">
                      <Calendar className="w-3.5 h-3.5" />
                      {inq.createdAt}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div className="p-2.5 bg-slate-50 rounded-xl">
                    <span className="text-slate-400 block mb-0.5">Утас:</span>
                    <a href={`tel:${inq.phone}`} className="font-bold text-amber-700 hover:underline">
                      {inq.phone}
                    </a>
                  </div>
                  <div className="p-2.5 bg-slate-50 rounded-xl">
                    <span className="text-slate-400 block mb-0.5">Имэйл:</span>
                    <span className="font-semibold text-slate-800">{inq.email || '-'}</span>
                  </div>
                  <div className="p-2.5 bg-slate-50 rounded-xl">
                    <span className="text-slate-400 block mb-0.5">Холбогдох чиглэл:</span>
                    <span className="font-semibold text-slate-800">
                      {inq.gradeLevel || inq.programInterest
                        ? `${inq.gradeLevel || ''} ${inq.programInterest ? '• ' + inq.programInterest : ''}`
                        : 'Ерөнхий санал хүсэлт'}
                    </span>
                  </div>
                </div>

                {messageBody && (
                  <div className="p-3.5 bg-amber-50/60 rounded-xl border border-amber-100 text-xs text-slate-800 leading-relaxed">
                    <span className="font-extrabold text-amber-950 block mb-1">
                      Санал хүсэлтийн агуулга:
                    </span>
                    <p className="whitespace-pre-line">{messageBody}</p>
                  </div>
                )}

                {/* Action bar */}
                <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-500 font-bold">Төлөв шинэчлэх:</span>
                    <select
                      value={inq.status}
                      onChange={(e) =>
                        updateInquiryStatus(inq.id, e.target.value as any)
                      }
                      className="text-xs bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg px-2.5 py-1 font-semibold focus:outline-hidden cursor-pointer"
                    >
                      <option value="new">Шинэ</option>
                      <option value="contacted">Холбогдсон</option>
                      <option value="approved">Шийдвэрлэсэн</option>
                      <option value="rejected">Татгалзсан</option>
                    </select>
                  </div>

                  <button
                    onClick={() => deleteInquiry(inq.id)}
                    className="text-xs text-red-500 hover:text-red-700 flex items-center gap-1 p-1.5 rounded-lg hover:bg-red-50 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Устгах</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
